from distutils.core import setup

setup(
    name='edempy',
    version='0.1.4',
    author='DEM Solutions Ltd.',
    author_email='support@edemsimulation.com',
    packages=['edempy','edempy.creatorData','edempy.timestep'],
    long_description=open('README.txt').read(),
    url='https://www.edemsimulation.com',
    license= 'Apache License Version 2.0',
    description='EDEM python post-processing library.',
    install_requires=[
        "numpy >= 1.14.3",
        "h5py >= 2.7.1",
    ],
   
)