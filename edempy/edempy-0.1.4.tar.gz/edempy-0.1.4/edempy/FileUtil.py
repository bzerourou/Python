'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import glob
import os

# ###################################################################################### #
# File conventions.
# ###################################################################################### #
def dataDirectory(demFile):
    """Returns the time-step data directory path corresponding to a .dem file path.

    Keyword arguments:
    ------------------
    demFile --  path to a .dem file (with or without the extension).
                Note that passing in a data directory will return the directory unchanged.

    Returns:
    --------
    string --  assumed path to the corresponding data directory. Does not guarantee its existence.
    """    
    if demFile[-4:] == '.dem' or demFile[-4:] == '_data' :
        demFile = demFile[:-4]
    return demFile + '_data' 

def dataDirectoryExists(demFile):
    """Determine if an EDEM data directory exists.

    Keyword arguments:
    ------------------
    demFile -- path to a dem data directory (with or without the _data suffix) OR path to .dem file.

    Returns:
    --------
    boolean -- true iff the data directory (having ensured it has _data suffix) exists.
    """    
    if demFile[-4:] != '_data' :
        demFile = dataDirectory(demFile)
    return os.path.isdir(demFile)

def listDeckNames(directory = ''):
    """Returns a list of valid EDEM decks' names in a directory.
    The names returned will be the root name: e.g. XXX for XXX.dem, XXX_data, etc.

    Keyword arguments:
    ------------------
    directory -- path to search.

    Returns:
    --------
    list -- list of paths (with the given directory prepended), but without extensions. 
            Only files where both *.dem exists and the corresponding *_data directory exist will be included. 
    """    

    # If needed, append a slash to the directory to search:
    if directory != '' and directory[-1:] != '/' :
        directory = directory + '/'

    # We're looking for *.dem files, but just the name, remove the extension:
    names = list(map(lambda x: x[:-4], glob.glob(directory + '*.dem')))
    # Assure that there is a corresponding  *_data directory
    return list(filter(lambda x: dataDirectoryExists(x), names))


def h5fileList(directory):
    """Returns list of h5 file names in specified directory.

    Keyword arguments:
    ------------------
    directory -- path to search.

    Returns:
    --------
    list -- list of h5 file names in specified directory, e.g. 0.h5, 1.h5, etc.
    """ 
    h5files = list(glob.glob(directory + '/*.h5'))
    return h5files