'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py

from .SSCollision import SSCollision
from .SGCollision import SGCollision

class Collision:
    """Collisions class used to access collision data from current timestep.

    Attributes:
    -----------
    surfSurf -- SSCollision object used to access collision properties for surface to surface collisions
    surfGeom -- SGCollision object used to access collision properties for surface to geometry collisions
    """

    def __init__(self, fname, fileVersion, timestep, creatorData):
        self.__fname = fname
        self.__fileVersion = fileVersion
        self.__timestep = timestep
        #keep hdf5 path to Geometry Group group as string
        self.__collisionPath = 'TimestepData/' + self.__timestep + '/Collisions'


        #get correct paths for surface-surface and surface-geometry collisions
        surfPath = self.__collisionPath + '/SurfaceSurface'
        geomPath = self.__collisionPath + '/SurfaceGeometry'

        ##@var surfSurf 
        # SSCollision object used to access collision properties for surface to surface collisions
        self.surfSurf = SSCollision(self.__fname, self.__fileVersion, surfPath, creatorData)
        
        ##@var surfGeom 
        # SGCollision object used to access collision properties for surface to geometry collisions
        self.surfGeom = SGCollision(self.__fname, self.__fileVersion, geomPath, creatorData)
    
    
