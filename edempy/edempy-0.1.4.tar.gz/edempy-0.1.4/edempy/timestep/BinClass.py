'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy


class BinClass:
    """Class inheritied by contact, particleType, bond classes to extract data into bins."""

    def __init__(self, edempyObject, dMin, dMax):
        self.__edempyObject = edempyObject
        self.__dMin = dMin
        self.__dMax = dMax

    '''
    BINNING PROPERTIES
    __________________
    '''

    def getAxisBinEdges(self, numBins, axis, dMin=None, dMax = None):
        """Returns numpy.ndarray of bin edge values for chosen axis

        Keyword Arguments:
        ----------
        numBins -- amount of bin divisions to split the data into
        axis -- string - 'x', 'y', 'z' chosen axis to get bin values from
        dMin -- optional - list of x,y,z coords to be used as minimum bin value
        dMax -- optional - list of x,y,z coords to be used as maximum bin value
        """
        #set default values for max and min domain
        if dMin == None:
            dMin = self.__dMin
        if dMax == None:
            dMax = self.__dMax

        #convert axis string into 0,1,2 values
        allAxis = {'x':0, 'y':1, 'z':2}
        index = allAxis[axis]

        minVal = dMin[index] #axis minimum domain value
        maxVal = dMax[index] #axis minimum domain value

        rangeVal = maxVal - minVal #domain range
        interval = rangeVal / numBins #calculated interval step for bin edges

        #set up bin-edge values for chosen axis, increasing in steps of interval value
        binEdges = [minVal]
        for i in range(1,numBins+1):
            binEdges.append(i * interval + minVal)

        return numpy.asarray(binEdges) #convert to numpy array


    def getAxisBinIndices(self, numBins, axis, dMin=None, dMax = None):
        """Returns numpy.ndarray of binned data for timestep for chosen axis, i.e. splits data along one axis direction only.

        Keyword Arguments: 
        ----------
        numBins -- set number of bins for chosen axis
        axis -- string - 'x', 'y', 'z' chosen axis to get bin values from
        dMin -- optional - list of x,y,z coords to be used as minimum bin value
        dMax -- optional - list of x,y,z coords to be used as maximum bin value

        Returns:
        --------
        binIndices -- numpy.ndarray of bin indices that extracted data corresponds to in the bins
        binEdges -- numpy.ndarray of bin edge values of bins (lower edge value)
        """
        #get bin edge values
        binEdges = self.getAxisBinEdges(numBins, axis, dMin, dMax)
        #convert axis string into 0,1,2 values
        allAxis = {'x':0, 'y':1, 'z':2}
        index = allAxis[axis]

        #get positions for binning data, and chosen property to bin
        positions = []
        try:
            #get positions of all contacts
            positions.extend(self.__edempyObject.getPositions())
        except IndexError:
            #if there aren't any particles present then don't attempt to read them
            pass
        positions = numpy.asarray(positions) #convert positions to numpy array

        #now need to digitize position for each of these binEdges to get 3D bin indices.
        #bin index for position is:
        binIndices =  numpy.digitize(positions[:,index], binEdges)
        return binIndices, binEdges


    def getAveragedBinData(self, numX, numY, numZ, binnedData):
        """Returns 3D numpy.ndarray of averaged binned data."""
        #generate x*y*z dimension empty list of lists so can append values of chosen property to it
        averageValues = [[[[] for _ in range(numZ)] for _ in range(numY)] for _ in range(numX)]
        for x in range(numX):
            for y in range(numY):
                for z in range(numZ):
                    #average all values in array and replace with these values
                    binVal = binnedData[x][y][z]
                    if binVal == []:
                        pass
                    else:
                        averageValues[x][y][z] = numpy.mean(binVal, axis=0).tolist()
        return numpy.asarray(averageValues)
    

    def getBinCoords(self, axisBinEdges):
        """Returns numpy.ndarray of 1D coordinates for the center of a given list of bin edges.
        
        Keyword Arguments:
        ------------------
        axisBinEdges -- numpy.ndarray of bin edge values (low value starting edge of each bin)
        """
        binCoords = []
        axisBinEdges = axisBinEdges.tolist()
        #go through all elements of axisbinedges apart from the last one, 
        #and calculate the average value of adjacent pairs to get the center point between.
        for i in range(len(axisBinEdges)-1):
            value = numpy.mean([axisBinEdges[i], axisBinEdges[i+1]])
            binCoords.append(value)
        return numpy.asarray(binCoords)


    def getBinnedProperty(self, numX, numY, numZ, dMin=None, dMax = None, option='default', average = False):
        """Returns 3D numpy.ndarray of binned data for timestep.

        Arguments:
        ----------
        numX -- set number of bins in x direction
        numY -- set number of bins in y direction
        numZ -- set number of bins in z direction
        dMin -- optional - list of x,y,z coords to be used as minimum bin value
        dMax -- optional - list of x,y,z coords to be used as maximum bin value
        option -- optional, choose which particle property to bin, default value is 'contact ids'.
        -> for bonds: >>> 'bonds', 'break time', 'normal force', 'normal torque', 'state', 'tangential force', 'tangential torque'
        -> for contacts: >>> 'contact ids', contact vector 1', 'contact vector 2', 'contacts', 'normal force', 'normal overlap',
        'position', 'tangential force', 'tangential overlap'.
        -> for particle: >>> 'ids', 'position', 'velocity', 'angular velocity', 'creation time',
        'scale', 'external force torque', 'force torque', 'orientation', 'spheres',
        'us_force torque'

        average -- True or False, whether or not to average the data in each bin

        Returns:
        --------
        binnedValues (numpy.ndarray) -- the 3D binned data for chosen property (averaged data if average = True)
        xBinCoords (numpy.ndarray) -- the x coordinates of the center of the bins
        yBinCoords (numpy.ndarray) -- the y coordinates of the center of the bins
        zBinCoords (numpy.ndarray) -- the z coordinates of the center of the bins
        """
        #get bin index values (what bin to put data in) and bin edge values for chosen bin dimension
        xBinIndices, xBinEdges =  self.getAxisBinIndices(numX, 'x', dMin, dMax)
        yBinIndices, yBinEdges =  self.getAxisBinIndices(numY, 'y', dMin, dMax)
        zBinIndices, zBinEdges =  self.getAxisBinIndices(numZ, 'z', dMin, dMax)

        xBinCoords = self.getBinCoords(xBinEdges)
        yBinCoords = self.getBinCoords(yBinEdges)
        zBinCoords = self.getBinCoords(zBinEdges)

        #get list of selected data property
        if option == 'default':
            selectedProperty = numpy.asarray(self.__edempyObject.getIds())
        else:
            selectedProperty = self.__edempyObject.getProperty(option)

        #generate x*y*z dimension empty list of lists so can append values of chosen property to it
        binnedValues = [[[[] for _ in range(numZ)] for _ in range(numY)] for _ in range(numX)]
       
        #fill this array with the common id values from the x,y,z binned data for each x,y,z domain grid bin
        for index, [x, y, z, sProp] in enumerate(zip(xBinIndices, yBinIndices, zBinIndices, selectedProperty), start=0):
            if any([x == 0, y == 0, z == 0, x == numX+1, y == numY+1, z == numZ+1]):
                #bin index is out of bounds so property in question is located outside of the binned domain
                pass

            else:
            #add value to array
            #need to -1 as bin indices start from 1.
                binnedValues[x-1][y-1][z-1].append(sProp.tolist())
        
        if average:
            return self.getAveragedBinData(numX,numY, numZ, binnedValues), xBinCoords, yBinCoords, zBinCoords

        #return as a numpy array for easier slicing of data
        return numpy.asarray(binnedValues), xBinCoords, yBinCoords, zBinCoords