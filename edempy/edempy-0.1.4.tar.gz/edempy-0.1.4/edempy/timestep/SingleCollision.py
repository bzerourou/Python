'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy 
import h5py

import abc
from .CustomProperties import CustomProperties

class SingleCollision(metaclass = abc.ABCMeta):
    """singleCollision class used to access collision properties for surface-surface and surface-geometry collisions.
    
    Attributes:
    -----------
    options -- list of available property options that can be used to bin data
    """


    def __init__(self, fname, fileVersion, collisionPath, creatorData):
        #open h5file
        self.__fname = fname
        self.__fileVersion = fileVersion
        self.__collisionPath = collisionPath
        self.__creatorData = creatorData

        ##@var options
        # list of available property options that can be used to bin data
        self.options = ['end time', 'ids', 'max normal force', 'max tangential force', 'normal energy',
        'number iterations', 'position', 'relative velocity', 'shear energy', 'start time',
        'total normal force', 'total tangential force', 'unitcp vector']

        if self.__creatorData._CreatorData__demfileVersion >= 2621972: # from this version onwards we have custom property meta data stored in the dem file
            self.customProperties = {}
            self.numCustomProperties = self.__creatorData.numContactCustomProperties

            for i, name, h5name in zip(range(self.numCustomProperties), self.__creatorData.contactCustomPropertyNames, self.__creatorData.h5ContactCustomPropertyNames):
                customProp = CustomProperties(self.__fname, self.__fileVersion, i, self.__collisionPath)
                
                self.customProperties[i] = customProp
                self.customProperties[name] = customProp
                self.customProperties[h5name] = customProp
        else:
            try:
                #instantiate a CustomProperty object for each custom property present for collision
                temp = h5py.File(self.__fname, 'r')
                self.numCustomProperties = len(list(temp[self.__collisionPath + '/CustomProperties/'].keys()))
                temp.close()
            except KeyError:
                self.numCustomProperties = 0

            # create array of custom properties, accessed by index number not necessarily the same as hdf5 number TODO make these numbers match
            self.customProperties = []
            for i in range(self.numCustomProperties):
                self.customProperties.append(CustomProperties(self.__fname, self.__fileVersion, i, self.__collisionPath))
        



    def getProperty(self, option):
        """Returns (multi-dimensional) numpy.ndarray of chosen collision data.

        Arguments:
        ----------
        option -- string - name of property 
        -> 'end time', 'ids', 'max normal force', 'max tangential force', 'normal energy',
        'number iterations', 'position', 'relative velocity', 'shear energy', 'start time',
        'total normal force', 'total tangential force', 'unitcp vector'.
        """
        f = h5py.File(self.__fname, 'r')
        result = f[self.__collisionPath + '/'+ option + '/'][:]
        f.close()
        return result

    '''
    top level properties (in SurfaceSurface or SurfaceGeometry directory)
    ____________________
    '''

    def getEndTimes(self):
        """Returns numpy.ndarray of collision end times."""
        return self.getProperty('end time')

    def getIds(self):
        """Returns numpy.ndarray of collision ids."""
        return self.getProperty('ids')
    
    def getNumCollisions(self):
        """Returns int value of number of collisions in timestep."""
        try:
            f = h5py.File(self.__fname, 'r')
            result = int(f[self.__collisionPath].attrs['size'])
            f.close()
            return result
        except:
            result = int(0)
        return result

    def getMaxNormalForce(self):
        """Returns numpy.ndarray of collision maximum normal forces."""
        return self.getProperty('max normal force')
    

    def getXMaxNormalForce(self):
        """Returns numpy.ndarray of x component of collision maximum normal forces."""
        return self.getMaxNormalForce()[:,0]
    

    def getYMaxNormalForce(self):
        """Returns numpy.ndarray of y component of collision maximum normal forces."""
        return self.getMaxNormalForce()[:,1]
    

    def getZMaxNormalForce(self):
        """Returns numpy.ndarray of z component of collision maximum normal forces."""
        return self.getMaxNormalForce()[:,2]



    def getMaxTangentialForce(self):
        """Returns numpy.ndarray of collision maximum tangential force."""
        return self.getProperty('max tangential force')
    

    def getXMaxTangentialForce(self):
        """Returns numpy.ndarray of x component of collision maximum tangential force."""
        return self.getMaxTangentialForce()[:,0]    
    

    def getYMaxTangentialForce(self):
        """Returns numpy.ndarray of y component of collision maximum tangential force."""
        return self.getMaxTangentialForce()[:,1]    
    

    def getZMaxTangentialForce(self):
        """Returns numpy.ndarray of z component of collision maximum tangential force."""
        return self.getMaxTangentialForce()[:,2]    



    def getNormalEnergy(self):
        """Returns numpy.ndarray of collision normal energy."""
        return self.getProperty('normal energy')
    

    def getNumberIterations(self):
        """Returns numpy.ndarray of collision number iterations."""
        return self.getProperty('number iterations')
    

    def getPosition(self):
        """Returns 3D numpy.ndarray of collision x,y,z positions."""
        return self.getProperty('position')
    

    def getXPosition(self):
        """Returns numpy.ndarray of x component of collision positions."""
        return self.getPosition()[:,0]
    

    def getYPosition(self):
        """Returns numpy.ndarray of y component of collision positions."""
        return self.getPosition()[:,1]
    

    def getZPosition(self):
        """Returns numpy.ndarray of z component of collision positions."""
        return self.getPosition()[:,2]


    def getRelativeVelocity(self):
        """Returns numpy.ndarray of collision relative velocities."""
        return self.getProperty('relative velocity')
    

    def getXRelativeVelocity(self):
        """Returns numpy.ndarray of x component of collision relative velocities."""
        return self.getRelativeVelocity()[:,0]
    

    def getYRelativeVelocity(self):
        """Returns numpy.ndarray of y component of collision relative velocities."""
        return self.getRelativeVelocity()[:,1]
    

    def getZRelativeVelocity(self):
        """Returns numpy.ndarray of z component of collision relative velocities."""
        return self.getRelativeVelocity()[:,2]


    def getShearEnergy(self):
        """Returns numpy.ndarray of collision shear energies."""
        return self.getProperty('shear energy')
    

    def getStartTime(self):
        """Returns numpy.ndarray of collision start times."""
        return self.getProperty('start time')
    

    def getTotalNormalForce(self):
        """Returns numpy.ndarray of collision total normal force."""
        return self.getProperty('total normal force')
    

    def getXTotalNormalForce(self):
        """Returns numpy.ndarray of x component of collision total normal force."""
        return self.getTotalNormalForce()[:,0]
    

    def getYTotalNormalForce(self):
        """Returns numpy.ndarray of y component of collision total normal force."""
        return self.getTotalNormalForce()[:,1]
    

    def getZTotalNormalForce(self):
        """Returns numpy.ndarray of z component of collision total normal force."""
        return self.getTotalNormalForce()[:,2]


    def getTotalTangentialForce(self):
        """Returns numpy.ndarray of collision total tangential force."""
        return self.getProperty('total tangential force')
    

    def getXTotalTangentialForce(self):
        """Returns numpy.ndarray of x component of collision total tangential force."""
        return self.getTotalTangentialForce()[:,0]
    

    def getYTotalTangentialForce(self):
        """Returns numpy.ndarray of y component of collision total tangential force."""
        return self.getTotalTangentialForce()[:,1]
    

    def getZTotalTangentialForce(self):
        """Returns numpy.ndarray of z component of collision total tangential force."""
        return self.getTotalTangentialForce()[:,2]


    def getUnitcpVector(self):
        """Returns numpy.ndarray of collision unit cp vector."""
        return self.getProperty('unitcp vector')


    def getXUnitcpVector(self):
        """Returns x component of collision unit cp vector."""
        return self.getUnitcpVector()[:,0]
    

    def getYUnitcpVector(self):
        """Returns y component of collision unit cp vector."""
        return self.getUnitcpVector()[:,1]
    

    def getZUnitcpVector(self):
        """Returns z component of collision unit cp vector."""
        return self.getUnitcpVector()[:,2]

    '''
    properties found in 'first' directory
    _____________________________________
    '''
    

    def getFirstAngularVelocity(self):
        """Returns numpy.ndarray of first particles' angular velocities."""
        return self.getProperty('first/angular velocity')
    

    def getFirstXAngularVelocity(self):
        """Returns numpy.ndarray of x component of first particles' angular velocities."""
        return self.getFirstAngularVelocity()[:,0]    


    def getFirstYAngularVelocity(self):
        """Returns numpy.ndarray of y component of first particles' angular velocities."""
        return self.getFirstAngularVelocity()[:,1]    


    def getFirstZAngularVelocity(self):
        """Returns numpy.ndarray of z component of first particles' angular velocities."""
        return self.getFirstAngularVelocity()[:,2]    



    def getFirstIds(self):
        """Returns numpy.ndarray of first particles' ids."""
        return self.getProperty('first/ids')
    

    def getFirstOrientation(self):
        """Returns numpy.ndarray of first particles' orietations."""
        return self.getProperty('first/orientation')
    

    def getFirstPosition(self):
        """Returns numpy.ndarray of first particles' positions."""
        return self.getProperty('first/position')
    

    def getFirstXPosition(self):
        """Returns numpy.ndarray of x component of first particles' positions."""
        return self.getFirstPosition()[:,0]    
    

    def getFirstYPosition(self):
        """Returns numpy.ndarray of y component of first particles' positions."""
        return self.getFirstPosition()[:,1]    
    

    def getFirstZPosition(self):
        """Returns numpy.ndarray of z component of first particles' positions."""
        return self.getFirstPosition()[:,2]    



    def getFirstRadius(self):
        """Returns numpy.ndarray of first particles' radii."""
        return self.getProperty('first/radius')
    

    def getFirstVelocity(self):
        """Returns numpy.ndarray of first particles' velocities."""
        return self.getProperty('first/velocity')


    def getFirstXVelocity(self):
        """Returns numpy.ndarray of x component of first particles' velocities."""
        return self.getFirstVelocity()[:,0]


    def getFirstYVelocity(self):
        """Returns numpy.ndarray of y component of first particles' velocities."""
        return self.getFirstVelocity()[:,1]


    def getFirstZVelocity(self):
        """Returns numpy.ndarray of z component of first particles' velocities."""
        return self.getFirstVelocity()[:,2]

    '''
    properties found in 'second' directory
    _____________________________________
    '''
  

    #these functions are implemented by the inheriting class so that they are correct for each type of collision
    @abc.abstractmethod  
    def getSecondIds(self):
        ...

    @abc.abstractmethod  
    def getSecondPosition(self):
        ...

    @abc.abstractmethod  
    def getSecondVelocity(self):
        ...