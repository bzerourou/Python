'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy 
import h5py

from .SingleCollision import SingleCollision

class SGCollision(SingleCollision):
    """Surface - surface class used to access data for a surface to surface collision for the current timestep.
    Inherits all functions from the singleCollision class.
    """
    def __init__(self, fname, fileVersion, collisionPath, creatorData):
        super().__init__(fname, fileVersion, collisionPath, creatorData)
        self.__fname = fname
        self.__fileVersion = fileVersion
        self.__collisionPath = collisionPath


    def getSecondIds(self):
        """Returns numpy.ndarray of second collision object's ids (geometry)."""
        return self.getProperty('second/ids')
 

    def getSecondPosition(self):
        """Returns numpy.ndarray of second collision object's positions (geometry)."""
        return self.getProperty('second/position')
    

    def getSecondXPosition(self):
        """Returns numpy.ndarray of x component of second collision object's positions (geometry)."""
        return self.getSecondPosition()[:,0]
    

    def getSecondYPosition(self):
        """Returns numpy.ndarray of y component of second collision object's positions (geometry)."""
        return self.getSecondPosition()[:,1]
    

    def getSecondZPosition(self):
        """Returns numpy.ndarray of z component of second collision object's positions (geometry)."""
        return self.getSecondPosition()[:,2]


    def getSecondVelocity(self):
        """Returns numpy.ndarray of second collision object's velocities (geometry)."""
        return self.getProperty('second/velocity')
    

    def getSecondXVelocity(self):
        """Returns numpy.ndarray of x component of second collision object's velocities (geometry)."""
        return self.getSecondVelocity()[:,0]
    

    def getSecondYVelocity(self):
        """Returns numpy.ndarray of y component of second collision object's velocities (geometry)."""
        return self.getSecondVelocity()[:,1]
    

    def getSecondZVelocity(self):
        """Returns numpy.ndarray of z component of second collision object's velocities (geometry)."""
        return self.getSecondVelocity()[:,2]