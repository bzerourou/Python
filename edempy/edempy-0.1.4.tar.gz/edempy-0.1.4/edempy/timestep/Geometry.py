'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py

from .CustomProperties import CustomProperties

class Geometry:
    """Geometry class used to access geometry data from current timestep.
    
    Attributes:
    -----------
    options -- list of available property options that can be chosen
    """


    def __init__(self, fname, fileVersion, timestep, index, creatorData, id=None):
        self.__fname = fname
        self.__fileVersion = fileVersion
        self.__timestep = timestep
        self.__index = index

        self.__id = id

        #keep hdf5 path to 'Geometry Group' group as string
        self.__geomPath = 'TimestepData/' + self.__timestep + '/GeometryGroups/' + str(self.__index)
        
        #set up ability to access creatorData values
        self.__creatorData = creatorData

        #check number of geometry triangles present in geometry
        ##@var numGeometryTriangles
        # number of geometry triangles in geometry
        self.numGeometryTriangles = self.__creatorData.geometry[self.__index].numGeometryTriangles

        temp = h5py.File(self.__fname, 'r')

        if self.__creatorData._CreatorData__demfileVersion >= 2621972: # from this version onwards we have custom property meta data stored in the dem file
            self.customProperties = {}
            self.numCustomProperties = self.__creatorData.numGeometryCustomProperties

            for i, name, h5name in zip(range(self.numCustomProperties), self.__creatorData.geometryCustomPropertyNames, self.__creatorData.h5GeometryCustomPropertyNames):
                customProp = CustomProperties(self.__fname, self.__fileVersion, i, self.__geomPath)
                
                self.customProperties[i] = customProp
                self.customProperties[name] = customProp
                self.customProperties[h5name] = customProp
        else:
            #instantiate a CustomProperty object for each custom property present for geometry
            try:
                self.numCustomProperties = len(list(temp[self.__geomPath + '/CustomProperties/'].keys()))
            except KeyError:
                self.numCustomProperties = 0
            temp.close()

            # create array of custom properties, accessed by index number not necessarily the same as hdf5 number TODO make these numbers match
            self.customProperties = []
            for i in range(self.numCustomProperties):
                self.customProperties.append(CustomProperties(self.__fname, self.__fileVersion, i, self.__geomPath))

        ##@var options
        # list of available property options that can be chosen
        options = ['force torque', 'angvelandposlist']

        ##@var idToIndex 
        # dictionary used to get row index for a geometry triangle from given id
        self.idToIndex = None #dict(zip(ids, relativeIndex))
            
        ##@var indexToId 
        # dictionary used to get id for a geometry triangle from given row number
        self.indexToId = None #dict(zip(relativeIndex, ids))


    #extract geometry type from current geometry
    def getType(self):
        """Return integer value for geometry type as seen in h5 file."""
        return int(self.__index)


    '''
    Triangle IDs
    ___
    '''
    def setupIdsDict(self):
        """Set up mapping of geometry triangle index values to ids in order to access geometry triangle data by id."""

        #check there are geometry triangles present then pair all ids for current type and timestep with index number if not already set up
        if (self.numGeometryTriangles > 0 and (self.idToIndex == None) and (self.indexToId == None)):
            #get list of ids
            ids = self.getTriangleIds()
            #get positional index for each
            relativeIndex = []
            for i in range(len(ids)):
                relativeIndex.append(i)

            ##@var idToIndex 
            # dictionary used to get row index for a geometry from given id
            self.idToIndex = dict(zip(ids, relativeIndex))
            
            ##@var indexToId 
            # dictionary used to get id for a geometry from given row number
            self.indexToId = dict(zip(relativeIndex, ids))
       

    def emptyIdsDict(self):
        """Clear dictionaries mapping geometry triangle index values to ids in order to free up memory."""
        #remove elements and set values back to None
        self.idToIndex.clear()
        self.idToIndex = None
        
        self.indexToId.clear()
        self.indexToId = None



    def getTriangleIds(self):
        """Returns numpy.ndarray of ids for geometry triangles in timestep."""
        return self.__creatorData.geometry[self.__index].getTriangleIds()



    def getTriangleIdsSet(self):
        """Returns set of ids for geometry triangles in timestep."""
        return set(self.getTriangleIds())


    def getTriangleIdsMin(self):
        """Returns minimum geometry triangle id."""
        return self.getTriangleIds()[0]


    def getTriangleIdsMax(self):
        """Returns maximum geometry triangle id."""
        return max(self.getTriangleIdsSet())


    def getTriangleNodes(self, id = None):
        """Returns numpy.ndarray of ids for geometry triangles in timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0:
            return self.__creatorData.geometry[self.__index].getTriangleNodes()
        else:
            #setup mapping between index and id for geometry triangles
            self.setupIdsDict()
            #get corresponding index for id, return default nan values if non-existant
            index = self.idToIndex.get(id,None)
            if index == None:
                return  [numpy.nan, numpy.nan, numpy.nan]
            else:
                #return triangle nodes for given triangle id
                result = []
                result.append(self.__creatorData.geometry[self.__index].getTriangleNodes()[index])
                # here return 0th element of result to remove unwanted data type info (result is a 2d tuple of values and datatype)
                return result[0]


    #get generic property
    def getProperty(self, option, id=None, default = [numpy.nan]):
        """Returns (multi-dimensional) numpy.ndarray of chosen geometry data.

        Arguments:
        ----------
        option -- string - name of property 
        -> 'force torque', 'angvelandposlist'
        id -- triangle id to get property data from
        default -- defualt return value in case of no data
        """

        f = h5py.File(self.__fname, 'r')
        if self.numGeometryTriangles == 0:
            f.close()
            return numpy.asarray(default)
        elif id == None:
            result = numpy.asarray(f[self.__geomPath + '/' + option])
            f.close()
            return result

        else:
            #setup mapping between index and id for geometry triangles
            self.setupIdsDict()
            #get corresponding index for id, default if non-existant
            index = self.idToIndex.get(id,None)
            if index != None:
                result = numpy.asarray(f[self.__geomPath + '/' + option][index])
                f.close()
                return result
            else:
                f.close()
                return numpy.asarray(default)


    def __getForceTorque(self, id = None):
        """Returns 7 column numpy.ndarray of 3D force, 3D torque and compressibility."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('force torque', id, [numpy.nan, numpy.nan, numpy.nan,
                                                     numpy.nan, numpy.nan, numpy.nan,
                                                     numpy.nan,])

    def getCoM(self):
        """Returns the position of the centre of mass of the geometry."""
        with h5py.File(self.__fname, 'r') as f:
            CoM = f[self.__geomPath + '/'].attrs['centre of mass'] 
            if self.__fileVersion < 2621964: 
                return CoM
            else:
                calcCoM = numpy.matmul(self.getTransformMatrix(), (CoM[0], CoM[1], CoM[2], 1) )
                return calcCoM[0:3]

    def getForce(self, id = None):
        """Returns 3D numpy.ndarray of force on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.__getForceTorque(id)[:,:3]
        else:
            self.setupIdsDict()
            return self.__getForceTorque(id)[:3]


    def getXForce(self, id = None):
        """Returns numpy.ndarray of x component of force on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.getForce(id)[:,0]
        else:
            return self.getForce(id)[:,[0]]


    def getYForce(self, id = None):
        """Returns numpy.ndarray of y component of force on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.getForce(id)[:,1]
        else:
            return self.getForce(id)[:,[1]]


    def getZForce(self, id = None):
        """Returns numpy.ndarray of z component of force on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.getForce(id)[:,2]
        else:
            return self.getForce(id)[:,[2]]


    def getTorque(self, id = None):
        """Returns 3D numpy.ndarray of torque on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.__getForceTorque(id)[:,3:6]
        else:
            self.setupIdsDict()
            return self.__getForceTorque(id)[3:6]
    

    def getXTorque(self, id = None):
        """Returns numpy.ndarray of x component of torque on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.getTorque(id)[:,0]
        else:
            return self.getTorque(id)[0]
    

    def getYTorque(self, id = None):
        """Returns numpy.ndarray of y component of torque on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.getTorque(id)[:,1]
        else:
            return self.getTorque(id)[1]
    

    def getZTorque(self, id = None):
        """Returns numpy.ndarray of z component of torque on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.getTorque(id)[:,2]
        else:
            return self.getTorque(id)[2]


    def getMagnitudeOfCompressibility(self, id = None):
        """Returns numpy.ndarray of magnitude of compressibility on each geometry triangle."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0: # need to check number of geometry triangles aswell so we use the correct number of indices here
            return self.__getForceTorque(id)[:,6]
        else:
            self.setupIdsDict()
            return self.__getForceTorque(id)[6]


    def __getAngvelandposlist(self):
        """Non public function, returns 2 column numpy.ndarray of 3D angular velocity and 3D position."""
        return self.getProperty('angvelandposlist')


    def getAngularVelocity(self):
        """Returns numpy.ndarray of x,y,z components of angular velocity (from angvelandposlist)."""
        return self.__getAngvelandposlist()[0][0]

    def getXAngularVelocity(self):
        """Returns numpy.ndarray of x component of angular velocity (from angvelandposlist)."""
        return self.getAngularVelocity()[0]

    def getYAngularVelocity(self):
        """Returns numpy.ndarray of y component of angular velocity (from angvelandposlist)."""
        return self.getAngularVelocity()[1]

    def getZAngularVelocity(self):
        """Returns numpy.ndarray of z component of angular velocity (from angvelandposlist)."""
        return self.getAngularVelocity()[2]


    def getPositionPOA(self):
        """Returns numpy.ndarray of x,y,z components of position of point of action of geometry (from angvelandposlist)."""
        return self.__getAngvelandposlist()[0][1]

    def getXPositionPOA(self):
        """Returns numpy.ndarray of x component of position of point of action of geometry (from angvelandposlist)."""
        return self.getPositionPOA()[0]

    def getYPositionPOA(self):
        """Returns numpy.ndarray of y component of position of point of action of geometry (from angvelandposlist)."""
        return self.getPositionPOA()[1]

    def getZPositionPOA(self):
        """Returns numpy.ndarray of z component of position of point of action of geometry (from angvelandposlist)."""
        return self.getPositionPOA()[2]

    def getTransformMatrix(self):
        """Returns 4x4 transform matrix for geometry."""
        transformMatrix = self.__getGlobalTransformMatrix()
        return transformMatrix

    def __getXform(self):
        """Returns 4x4 translation matrix for geometry."""
        if self.__fileVersion < 2621964:
            f = h5py.File(self.__fname, 'r')
            result = f[self.__geomPath + '/'].attrs['xform']
            f.close()
        else:
            result = numpy.full(shape=(4,4), fill_value=numpy.nan)
        return numpy.asarray(result)

    def __getGlobalTransformMatrix(self):
        """Returns 4x4 global transform matrix for geometry."""
        result = self.getProperty('global transform')
        return numpy.asarray(result)

    def getSimulationTransformMatrix(self):
        """Returns 4x4 simulation transform matrix for geometry."""
        if self.__fileVersion >= 2621964: 
            result = self.getProperty('simulation transform')
        else:
            # provide compatiblity with older decks
            result = self.__getXform()
        return numpy.asarray(result)


    def getCoords(self, id = None):
        """Returns numpy.ndarray of current coordinates for geometry using translation matrix to get the accurate coordinates."""

        #make sure ids are set up if not already
        if id == None:
            id = self.__id

        creator_data_Geom = self.__creatorData.geometry[self.__index]
        tstep_Geom = self

        # Initialise 
        rotationMatrix  = numpy.empty(shape=(3,3), dtype=object)
        translation     = numpy.empty(3, dtype=object)
        
        if self.__fileVersion >= 2621964:
            # Get the transform matrix, which contains the rotation matrix and the geometry translation in a 4x4 matrix
            # This contains the movement of the geometry from kinematics / coupling interface
            transformMatrix = tstep_Geom.getTransformMatrix()
            calculatedCoords = self.__getCalculatedCoordinates(creator_data_Geom, transformMatrix, id)

        else:
            transformMatrix = tstep_Geom.__getXform()
            # Create a standalone rotation matrix
            for j in range(0,3):
                for k in range(0,3):
                    rotationMatrix[j][k] = transformMatrix[j][k]
        
            # And a standalone translation matrix
            for j in range(0,3):
                translation[j] = transformMatrix[j][3]            
                    
            # Check whether it's a CAD geometry 
            geometryType = creator_data_Geom.getTypeName() 
        
            # CAD geometries
            if (geometryType == 'cad_geometry'):
                cadTranslation = self.__getCadGeometryTranslation(creator_data_Geom)
                quaternion = self.__getCadGeometryQuaternion(creator_data_Geom)

            # EDEM Geometries           
            else:
                # Cylinders are a special case because they aren't defined with a centre - it doesn't exist in their h5 entry
                # Both the translation and rotation are back-calculated from the axis defining it
                if (geometryType == 'cylinder'):
                    axisStart      = creator_data_Geom.getCylinderStart()
                    axisEnd        = creator_data_Geom.getCylinderEnd()

                    cadTranslation   = self.__getCylinderTranslation(creator_data_Geom, axisStart, axisEnd)
                    quaternion = self.__getCylinderQuaternion(creator_data_Geom, axisStart, axisEnd)                
            
                # Boxes and polygons can be handled the same way, though different to cylinders, with centre and rotations from the h5
                else:
                    cadTranslation   = creator_data_Geom.getPolygonCentre()
                    quaternion = self.__getPolygonQuaternion(creator_data_Geom)
            
                # No matter where it was calculated from, all quaternions must be normalised
                quaternion    = normalize(quaternion)             
                
            calculatedCoords = self.__getCalculatedCoordinatesLegacy(creator_data_Geom, quaternion, cadTranslation, rotationMatrix, translation, id)

        return numpy.array(calculatedCoords, dtype=numpy.float64)


    def getXCoords(self, id = None):
        """Returns numpy.ndarray of current x coordinates for geometry using translation matrix to get the accurate coordinates."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0:
            return self.getCoords(id)[:,0]  # need to check number of geometry triangles aswell so we use the correct number of indices here
        else:
            return self.getCoords(id)[:,[0]]

    def getYCoords(self, id = None):
        """Returns numpy.ndarray of current y coordinates for geometry using translation matrix to get the accurate coordinates."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0:
            return self.getCoords(id)[:,1]  # need to check number of geometry triangles aswell so we use the correct number of indices here
        else:
            return self.getCoords(id)[:,[1]]

    def getZCoords(self, id = None):
        """Returns numpy.ndarray of current z coordinates for geometry using translation matrix to get the accurate coordinates."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0:
            return self.getCoords(id)[:,2]  # need to check number of geometry triangles aswell so we use the correct number of indices here
        else:
            return self.getCoords(id)[:,[2]]


    '''
    Quaternion and Translation calculations for CAD geometries, EDEM cylinders and EDEM polygons/boxes
    '''

    def __getCadGeometryTranslation(self, creator_data_Geom):
        """Returns the CAD translation matrix of a CAD geometry."""

        # Initial translation calculated from axis and distance moved
        translationAxisStart      = creator_data_Geom.getCadTranslationStart()
        translationAxisEnd        = creator_data_Geom.getCadTranslationEnd()
        cadTranslation            = creator_data_Geom.getCadTranslationDistance()
        
        translationAxisLength = numpy.linalg.norm(translationAxisEnd  - translationAxisStart)
        
        # Calculate the translation vector for CAD geometries
        if( translationAxisLength != 0):
            
            # Get the normalised vector of the axis direction
            normTranslationVector       = (translationAxisEnd  - translationAxisStart)/translationAxisLength
                            
            # Normal * Magnitude gives the overall translation
            cadTranslation= cadTranslation * normTranslationVector 

        return cadTranslation

    def __getCadGeometryQuaternion(self, creator_data_Geom):
        """Returns the quaternion of a CAD geometry."""

        # Initial rotation calculate from axis and rotations around axes
        rotationAxisStart       = creator_data_Geom.getCadRotationStart()

        rotationAxisEnd         = creator_data_Geom.getCadRotationEnd()

        cadRotation             = creator_data_Geom.getCadRotationAngle()
        
        rotationAxisLength      = numpy.linalg.norm(rotationAxisEnd - rotationAxisStart)
        
        # Calculate quaternion from rotations
        # https://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation
        if(rotationAxisLength != 0):             
            quaternion       = numpy.empty(4, dtype=object)
            axis             = (rotationAxisEnd - rotationAxisStart)/rotationAxisLength
            quaternion       = (numpy.cos(cadRotation/2) , axis[0]*numpy.sin(cadRotation/2), axis[1]*numpy.sin(cadRotation/2), axis[2]*numpy.sin(cadRotation/2))
        else:
            # If the axis length is zero, there's no rotation to apply so use the identity quaternion
            quaternion       = (1,0,0,0)


        # Normalise the quaternion
        quaternion    = normalize(quaternion)    
        return quaternion

    def __getCylinderTranslation(self, creator_data_Geom, axisStart, axisEnd):
        """Returns the translation matrix of an EDEM cylinder."""
        
        # Calling this cadTranslation still even though it's not a CAD geometry for consistency
        cadTranslation   = axisStart + ((axisEnd - axisStart) / 2)
                  
        return cadTranslation

    def __getCylinderQuaternion(self, creator_data_Geom, axisStart, axisEnd):
        """Returns the quaternion of an EDEM cylinder."""

        # For cylinders we need to back calculate the rotation from the initial axis (unit z) to the defined axis (end-start)
        # Method implemented
        # https://stackoverflow.com/questions/1171849/finding-quaternion-representing-the-rotation-from-one-vector-to-another

        # All newly created cylinders have their axis as (0,0,1)
        initialCylinderAxis = (0,0,1)

        definedCylinderAxis = (axisEnd - axisStart)/ numpy.linalg.norm(axisEnd - axisStart)

        # The complex components of the quaternion are calculated from the cross product of the vectors
        quaternion_ijk   = numpy.cross(initialCylinderAxis, definedCylinderAxis)

        # The constant component (cos theta/2) is calculated from the definition of the dot product ( |a||b|*cos(theta) )
        quaternion_const = numpy.sqrt(pow(numpy.linalg.norm(initialCylinderAxis),2) * pow(numpy.linalg.norm(definedCylinderAxis),2)) + numpy.dot(initialCylinderAxis, definedCylinderAxis)

        # Combine for the whole thing to get the rotation of the cylinder as a quaternion
        quaternion = (quaternion_const, quaternion_ijk[0], quaternion_ijk[1], quaternion_ijk[2])  

        # Normalise the quaternion
        quaternion = normalize(quaternion)   
        
        return quaternion

    def __getPolygonQuaternion(self, creator_data_Geom):
        """Returns the quaternion of an EDEM polygon or box."""

        # Get the angles of rotation for the x, y, z axes
        rotations   = creator_data_Geom.getPolygonRotation()

        # Calculate the quaternion from the rotation axis (a,b,c) and angle (theta)
        # q = cos(theta/2) + (ai + bj + ck)*sin(theta/2)
        # https://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation

        phi     = rotations[0]
        theta   = rotations[1]
        psi     = rotations[2]

        # Convert it all to quaternions
        quaternionX       = (numpy.cos(phi/2)     , numpy.sin(phi/2), 0                 , 0               )
        quaternionY       = (numpy.cos(theta/2)   , 0               , numpy.sin(theta/2), 0               )
        quaternionZ       = (numpy.cos(psi/2)     , 0               , 0                 , numpy.sin(psi/2))

        # Order of rotation for EDEM geometries is Y Z X (or X Z Y depending on how you look at it)
        quaternion    = q_mult(quaternionY, q_mult(quaternionZ, quaternionX))
        
        # Normalise the quaternion
        quaternion    = normalize(quaternion)   

        return quaternion


    '''
    Calculate the Coordinates for the geometry using the calculated values for the translation, cadTranslation, rotationMatrix and the quaternion
    '''
    def __getCalculatedCoordinatesLegacy(self, creator_data_Geom, quaternion, cadTranslation, rotationMatrix, translation, id = None):
        """Returns the calculated coordinates of a geometry using the quaternion, cad translation (calculated translation), rotation matrix and intial translation of a geometry."""

        calculatedCoords = []
        coords = creator_data_Geom.getCoords(id)

        if isinstance(coords[0], numpy.ndarray):

            # Loop over all coords 
            for coord in coords:

                # Apply translation & rotation data to the geometry coordinates
                # CAD rotation
                calcCoord      = numpy.array(qv_mult(quaternion, (coord[0], coord[1], coord[2]) ))
                # CAD translation
                calcCoord     += cadTranslation
                # Kinematic rotation
                calcCoord      = rotationMatrix.dot(calcCoord)
                # Kinematic translation
                calcCoord     += translation 

                calculatedCoords.append(calcCoord)

        else:
            coord = coords
            # Apply translation & rotation data to the geometry coordinates
            # CAD rotation
            calcCoord      = numpy.array(qv_mult(quaternion, (coord[0], coord[1], coord[2]) ))
            # CAD translation
            calcCoord     += cadTranslation
            # Kinematic rotation
            calcCoord      = rotationMatrix.dot(calcCoord)
            # Kinematic translation
            calcCoord     += translation 

            calculatedCoords.append(calcCoord)

        return calculatedCoords

    def __getCalculatedCoordinates(self, creator_data_Geom, globalTransform, id=None):
        """Returns the calculated coordinates of a geometry using the global transform."""

        calculatedCoords = []
        coords = creator_data_Geom.getCoords(id)

        if isinstance(coords[0], numpy.ndarray):

            # Loop over all coords 
            for coord in coords:
                x = coord[0]
                y = coord[1]
                z = coord[2]
                # Apply global transform to geometry calculate coordinates
                calcCoord      = numpy.matmul(globalTransform, (x, y, z, 1) )
                calculatedCoords.append(calcCoord[0:3]) #remove final column value as unnecessary
        else:
            coord = coords
            # Apply global transform to geometry calculate coordinates
            calcCoord      = numpy.matmul(globalTransform, (coord[0], coord[1], coord[2], 1) )
            calculatedCoords.append(calcCoord[0:3]) #remove final column value as unnecessary

        return calculatedCoords


# =======================================================================================
# The below - for quaternion calculations - obtained from:
# https://stackoverflow.com/questions/4870393/rotating-coordinate-system-via-a-quaternion    
# =======================================================================================    
def normalize(v, tolerance=0.00001):
    mag2 = sum(n * n for n in v)
    if abs(mag2 - 1.0) > tolerance:
        mag = numpy.sqrt(mag2)
        v = tuple(n / mag for n in v)
    return v

def q_mult(q1, q2):
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    w = w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2
    x = w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2
    y = w1 * y2 + y1 * w2 + z1 * x2 - x1 * z2
    z = w1 * z2 + z1 * w2 + x1 * y2 - y1 * x2
    return w, x, y, z
    
def q_conjugate(q):
    w, x, y, z = q
    return (w, -x, -y, -z)    
    
def qv_mult(q1, v1):
    q2 = (0.0,) + v1
    return q_mult(q_mult(q1, q2), q_conjugate(q1))[1:] 
