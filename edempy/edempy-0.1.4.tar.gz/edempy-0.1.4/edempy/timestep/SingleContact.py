'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy 
import h5py

import abc
from .BinClass import BinClass
from .CustomProperties import CustomProperties

class SingleContact(BinClass, metaclass = abc.ABCMeta):
    """singleContact class used to access contact properties for surface-surface and surface-geometry contacts.
    
    Attributes:
    -----------
    options -- list of available property options that can be used to bin data
    """
    

    def __init__(self, fname, fileVersion, timestep, contactPath, particleType, creatorData, dMin, dMax):
        super().__init__(self, dMin, dMax) #get access to bin class functions
        self.__fname = fname
        self.__fileVersion = fileVersion
        self.__timestep = timestep
        self.__contactPath = contactPath
        self.__particleType = particleType
        self.__creatorData = creatorData
        self.__dMin = dMin
        self.__dMax = dMax
        ##@var options
        # list of available property options that can be used to bin data
        self.options = ['contact vector 1', 'contact vector 2', 'contacts', 'normal force', 'normal overlap',
        'position', 'tangential force', 'tangential overlap' ]
        
        if self.__creatorData._CreatorData__demfileVersion >= 2621972: # from this version onwards we have custom property meta data stored in the dem file
            self.customProperties = {}
            self.numCustomProperties = self.__creatorData.numContactCustomProperties

            for i, name, h5name in zip(range(self.numCustomProperties), self.__creatorData.contactCustomPropertyNames, self.__creatorData.h5ContactCustomPropertyNames):
                customProp = CustomProperties(self.__fname, self.__fileVersion, i, self.__contactPath)
                
                self.customProperties[i] = customProp
                self.customProperties[name] = customProp
                self.customProperties[h5name] = customProp
        else:
            try:
                #instantiate a CustomProperty object for each custom property present for contact
                temp = h5py.File(self.__fname, 'r')
                self.numCustomProperties = len(list(temp[self.__contactPath + '/CustomProperties/'].keys()))
                temp.close()
            except KeyError:
                self.numCustomProperties = 0

            # create array of custom properties, accessed by index number not necessarily the same as hdf5 number TODO make these numbers match
            self.customProperties = []
            for i in range(self.numCustomProperties):
                self.customProperties.append(CustomProperties(self.__fname, self.__fileVersion, i, self.__contactPath))
        

    #force this function to be implemented by the sub class that inherits from this one
    #so that binned property function be placed here and not in each of the SSContact and SGContact classes.
    @abc.abstractmethod
    def getIds(self):
        ...

    @abc.abstractmethod
    def getNegativeNormalOverlap(self):
        ...


    def getProperty(self, option):
        """Returns (multi-dimensional) numpy.ndarray of chosen contact data.

        Arguments:
        ----------
        option -- string - name of property 
        -> 'contact vector 1', 'contact vector 2', 'contacts', 'normal force', 'normal overlap',
        'position', 'tangential force', 'tangential overlap'  
        """
        f = h5py.File(self.__fname, 'r')
        result = f[self.__contactPath + '/'+ option + '/'][:]
        f.close()
        return result


    def getNumContacts(self):
        """Returns int value of number of contacts in timestep."""
        try:
            f = h5py.File(self.__fname, 'r')
            result = int(f[self.__contactPath].attrs['size'])
            f.close()
            return result
        except:
            result = int(0)
        return result
        

    def getTypeIDs(self):
        """Returns numpy.ndarray of contact types for each particle in the contact."""
        #return first and third column of the contact data as this is the particle type
        return self.getContacts()[:,[0,2]]


    def getContactVector1(self):
        """Returns 3D numpy.ndarray of contact vector 1."""
        return self.getProperty('contact vector 1')
       

    def getXContactVector1(self):
        """Returns numpy.ndarray of x component of contact vector 1."""
        return self.getContactVector1()[:,0]
    

    def getYContactVector1(self):
        """Returns numpy.ndarray of y component of contact vector 1."""
        return self.getContactVector1()[:,1]
    

    def getZContactVector1(self):
        """Returns numpy.ndarray of z component of contact vector 1."""
        return self.getContactVector1()[:,2]


    def getContactVector2(self):
        """Returns 3D numpy.ndarray of contact vector 2."""
        return self.getProperty('contact vector 2')
   

    def getXContactVector2(self):
        """Returns numpy.ndarray of x component of contact vector 2."""
        return self.getContactVector2()[:,0]


    def getYContactVector2(self):
        """Returns numpy.ndarray of y component of contact vector 2."""
        return self.getContactVector2()[:,1]


    def getZContactVector2(self):
        """Returns numpy.ndarray of z component of contact vector 2."""
        return self.getContactVector2()[:,2]


    def getContacts(self):
        """Returns numpy.ndarray of contacts."""
        return self.getProperty('contacts')


    def getNormalForce(self):
        """Returns numpy.ndarray of normal force."""
        return self.getProperty('normal force')


    def getXNormalForce(self):
        """Returns numpy.ndarray of x component of normal force."""
        return self.getNormalForce()[:,0]


    def getYNormalForce(self):
        """Returns numpy.ndarray of y component of normal force."""
        return self.getNormalForce()[:,1]


    def getZNormalForce(self):
        """Returns numpy.ndarray of z component of normal force."""
        return self.getNormalForce()[:,2]


    def getNormalOverlap(self):
        """Returns numpy.ndarray of normal overlap."""
        return self.getProperty('normal overlap')


    def getPositions(self):
        """Returns numpy.ndarray of x,y,z, components of positions."""
        return self.getProperty('position')


    def getXPositions(self):
        """Returns numpy.ndarray of x component of position."""
        return self.getPositions()[:,0]
        

    def getYPositions(self):
        """Returns numpy.ndarray of y component of position."""
        return self.getPositions()[:,1]
    

    def getZPositions(self):
        """Returns numpy.ndarray of z component of position."""
        return self.getPositions()[:,2]


    def getTangentialForce(self):
        """Returns numpy.ndarray of x,y,z components of tangential force."""
        return self.getProperty('tangential force')


    def getXTangentialForce(self):
        """Returns numpy.ndarray of x components of tangential force."""
        return self.getTangentialForce()[:,0]


    def getYTangentialForce(self):
        """Returns numpy.ndarray of y components of tangential force."""
        return self.getTangentialForce()[:,1]


    def getZTangentialForce(self):
        """Returns numpy.ndarray of z components of tangential force."""
        return self.getTangentialForce()[:,2]


    def getTangentialOverlap(self):
        """Returns numpy.ndarray of tangential overlap."""
        return self.getProperty('tangential overlap')


    def getXTangentialOverlap(self):
        """Returns numpy.ndarray of x component of tangential overlap."""
        return self.getTangentialOverlap()[:,0]
        

    def getYTangentialOverlap(self):
        """Returns numpy.ndarray of y component of tangential overlap."""
        return self.getTangentialOverlap()[:,1]


    def getZTangentialOverlap(self):
        """Returns numpy.ndarray of z component of tangential overlap."""
        return self.getTangentialOverlap()[:,2]

