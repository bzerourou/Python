'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py


from .Bond import Bond
from .Collision import Collision
from .Contact import Contact
from .Geometry import Geometry
from .GeometryTriangle import GeometryTriangle
from .ParticleType import ParticleType
from .Particle import Particle
from .SystemEnergy import SystemEnergy
from .CustomProperties import CustomProperties

class Timestep:
    """Timestep class used to access simulation data from a specific timestep.

    Attributes:
    -----------
    timestep -- current timestep value (exact value for timestep)
    numTypes -- number of different types of particle
    numGeoms -- number of different geometries
    particle -- dictionary of ParticleType objects used to access particle data for each type of particle
    geometry -- dictionary of Geometry objects representing each geometry in the simulation, used to get geometry data
    bond -- Bond object used to access bond data for current timestep
    contact -- Contact object used to access contact data for current timestep for surface-surface and surface-geometry contacts
    energy -- SystemEnergy object used to access energy data for the current timestep
    collision -- Collision object used to access the collision data for the current timestep
    """

    #open h5 file and get path to particle as string, count number of 
    # types of particle materials

    def __init__(self, h5file, numTypes, numGeoms, dMin, dMax, creatorData):

        self.__fname = h5file
        # get timestep value for hdf5 directory, for use in
        # instantiating other class members in this class
        temp = h5py.File(self.__fname, 'r')
        self.__timestep = list(temp['TimestepData'].keys())[0]
        
        ## @var fileVersion
        # EDEM file version used to write the file
        self.__fileVersion = temp['TimestepData/' + self.__timestep + '/'].attrs['file version'] 
        temp.close()

        self.__creatorData = creatorData

        ##@var timestep 
        # current timestep value (exact value for timestep)
        #accurate value for timestep, should not be used for instantiating other class members of timestep
        self.timestep = self.__getTimestep()
        
        ##@var numTypes 
        # number of different types of particle
        self.numTypes = numTypes

        ##@var numGeoms 
        # number of different geometries
        self.numGeoms = numGeoms

        self.__dMin = dMin
        self.__dMax = dMax
    
        '''
        Particle Type Instantiation
        ______________________
        '''
        self.__particleType = [] #list access to particleType data
        
        ##@var particle 
        # dictionary of ParticleType objects used to access particle data for each type of particle
        self.particle = {} 

        for h5PType in self.__creatorData.h5PTypes:
            #make list of particleType objects to allow access to the data by indices
            self.__particleType.append(ParticleType(self.__fname, self.__creatorData, self.__fileVersion, self.__timestep, h5PType, dMin, dMax))

        #create a dictionary to access the particle type data by either using an index number, h5 file number or particle name as set by user.
        # e.g. particle[0], particle['5'], particle['rock particle'] will all return the same thing if particle '5' was named 'rock particle' 
        # and was the smallest number value particle in h5 file.
        for index, h5PType, pName in zip(range(self.numTypes), self.__creatorData.h5PTypes, self.__creatorData.particleNames):
            self.particle[index] = self.__particleType[index]
            self.particle[str(h5PType)] = self.__particleType[index]
            self.particle[str(pName)] = self.__particleType[index]                                                                 

        '''
        Geometry Instantiation
        ______________________
        '''
        self.__geometryType = [] #list access to geometryType data
        
        ##@var geometry 
        # dictionary of Geometry objects representing each geometry in the simulation, used to get geometry data
        self.geometry = {} 

        for h5GType in self.__creatorData.h5GTypes:
            #make list of geometry type objects to allow access to the data by indices
            self.__geometryType.append(Geometry(self.__fname, self.__fileVersion, self.__timestep, h5GType, self.__creatorData))
       
        #create a dictionary to access the particle type data by either using an index number, h5 file number or particle name as set by user.
        # e.g. particle[0], particle['5'], particle['rock particle'] will all return the same thing if particle '5' was named 'rock particle' 
        # and was the smallest number value particle in h5 file.
        for index, h5GType, gName in zip(range(self.numGeoms), self.__creatorData.h5GTypes, self.__creatorData.geometryNames):
            self.geometry[index] = self.__geometryType[index]
            self.geometry[str(h5GType)] = self.__geometryType[index]
            self.geometry[str(gName)] = self.__geometryType[index]   
        
        '''
        Bond Instantiation
        ______________________
        '''
        ##@var bond 
        # Bond object used to access bond data for current timestep
        
        # particleType dictionary is passed in order for contact ids to be easily extracted using 
        # available functions of ParticleType class
        self.bond = Bond(self.__fname, self.__fileVersion, self.__timestep, self.particle, self.__dMin, self.__dMax)

        '''
        Contact Instantiation
        ______________________
        '''
        


        ##@var contact 
        # Contact object used to access contact data for current timestep for surface-surface and surface-geometry contacts
        
        # generate contact object for surface-surface and surface-geometry
        # particleType list is passed in order for contact ids to be easily extracted using ParticleType functions
        self.contact = Contact(self.__fname, self.__fileVersion, self.__timestep, self.particle, self.geometry, self.__creatorData, self.__dMin, self.__dMax)
        
        '''
        System Energy Instantiation
        ______________________
        '''
        ##@var energy 
        # SystemEnergy object used to access energy data for the current timestep
        self.energy = SystemEnergy(self.__fname, self.__fileVersion, self.__timestep)

        '''
        Collision Instantiation
        _______________________
        '''
        ##@var collision 
        # Collision object used to access the collision data for the current timestep
        self.collision = Collision(self.__fname, self.__fileVersion, self.__timestep, self.__creatorData)


        '''
        Custom Properties Instantiation
        _______________________________
        '''

        if self.__creatorData._CreatorData__demfileVersion >= 2621972: # from this version onwards we have custom property meta data stored in the dem file
            self.customProperties = {}
            self.numCustomProperties = self.__creatorData.numSimulationCustomProperties

            for i, name, h5name in zip(range(self.numCustomProperties), self.__creatorData.simulationCustomPropertyNames, self.__creatorData.h5SimulationCustomPropertyNames):
                customProp = CustomProperties(self.__fname, self.__fileVersion, i, 'TimestepData/' + str(self.__timestep))
                
                self.customProperties[i] = customProp
                self.customProperties[name] = customProp
                self.customProperties[h5name] = customProp
        else:
            #instantiate a CustomProperty object for each custom property present for particle type
            try:
                temp = h5py.File(self.__fname, 'r')
                self.numCustomProperties = len(list(temp['TimestepData/' + str(self.__timestep) + '/CustomProperties'].keys()))

                temp.close()
            except KeyError:
                self.numCustomProperties = 0

            # create array of custom properties, accessed by index number not necessarily the same as hdf5 number TODO make these numbers match
            self.customProperties = []
            for i in range(self.numCustomProperties):
                self.customProperties.append(CustomProperties(self.__fname, self.__fileVersion, i, 'TimestepData/' + str(self.__timestep))) #standard custom props


    def getRemovedParticles(self):
        """Returns 2d numpy.ndarray of particle types (column 0) and total number removed for each (column 1)."""
        f = h5py.File(self.__fname, 'r')
        result = f['TimestepData/' + self.__timestep + '/removed particles/'][:]
        f.close()
        return result


    def __str__(self):
        """Returns string value of timestep used in hdf5 file (not the exact timestep value)."""
        return self.__timestep

    '''
    Get Particle Instance (by ID)
    __________________
    '''

    def getParticle(self, id):
        """Returns Particle object used to group and access data for a specific particle.
        
        Arguments:
        ----------
        id -- particle's reference ID number
        """
        pType = self.getParticleType(id)
        return Particle(self.__fname, self.__creatorData, self.__fileVersion, self.__timestep, pType, self.__dMin, self.__dMax, id)

    '''
    ___________________________________________________________________
    Get Particle Information From reference ID
    ___________________________________________________________________
    '''
    #get particle type from inputted id to allow easier way to 
    # get contact ids with more than one type of particle

    def getParticleType(self, id):
        """Returns integer h5 particle type number for a given particle id.
        
        Keyword Arguments:
        ------------------
        id -- ID number for particle that the type is to be determined for
        """

        partType = -1 #will only still be -1 if particle id doesn't exist
        for pType in self.__particleType:
            idSet = (pType.getIdsSet())
            if id in idSet:
                partType = pType.getType()
                break
        return partType


    def getBinnedPropertyAll(self, numX, numY, numZ, option='ids', average = False):
        """Returns 3D numpy.ndarray of binned data for all types of particle in timestep.

        Keyword Arguments:
        ----------
        numX -- set number of bins in x direction
        numY -- set number of bins in y direction
        numZ -- set number of bins in z direction
        option -- optional, default value is 'ids', choose which particle property to bin 
        -> 'position', 'velocity', 'angular velocity', 'creation time', 'scale', 
        'external force torque' 'force torque', 'orientation', 'us_force torque', ('spheres').
        average -- True or False, whether or not to average the data in each bin

        Returns:
        --------
        binnedValues (numpy.ndarray) -- the 3D binned data for chosen property (averaged data if average = True)
        xBinCoords (numpy.ndarray) -- the x coordinates of the center of the bins
        yBinCoords (numpy.ndarray) -- the y coordinates of the center of the bins
        zBinCoords (numpy.ndarray) -- the z coordinates of the center of the bins
        """
        dMin = self.__dMin
        dMax = self.__dMax

        xMin = dMin[0];     xMax = dMax[0]
        yMin = dMin[1];     yMax = dMax[1]
        zMin = dMin[2];     zMax = dMax[2]
       
        xRange = xMax - xMin;   yRange = yMax - yMin;   zRange = zMax - zMin
        xInt = xRange / numX;   yInt = yRange / numY;   zInt = zRange / numZ

        #set up bin-edge values for whole domain, increasing in steps of interval value
        xBinEdges = [xMin];     yBinEdges = [yMin];    zBinEdges = [zMin] 
        for i in range(1,numX+1):
            xBinEdges.append(i * xInt + xMin)
        for i in range(1,numY+1):
            yBinEdges.append(i * yInt + yMin)
        for i in range(1,numZ+1):
            zBinEdges.append(i * zInt + zMin)

        xBinEdges = numpy.asarray(xBinEdges) #convert to numpy array
        yBinEdges = numpy.asarray(yBinEdges) #convert to numpy array
        zBinEdges = numpy.asarray(zBinEdges) #convert to numpy array
    
        xBinCoords = self.getBinCoords(xBinEdges)
        yBinCoords = self.getBinCoords(yBinEdges)
        zBinCoords = self.getBinCoords(zBinEdges)


        #get positions for binning data, and chosen property to bin
        positions = []
        selectedProperty = []
        for pType in self.__particleType:
            try:
                #get ids for all types of particle
                selectedProperty.extend(pType.getProperty(option)) 
                #get positions for all types of particle  
                positions.extend(pType.getPositions())
            except IndexError:
                #if there aren't any particles present then don't attempt to read them
                pass

        positions = numpy.asarray(positions)

        #now need to digitize position for each of these BinEdges to get 3D bin indices.
        #now get property corresponding to bins
        #bin index for position is:
        xBinIndices =  numpy.digitize(positions[:,0], xBinEdges)
        yBinIndices =  numpy.digitize(positions[:,1], yBinEdges)
        zBinIndices =  numpy.digitize(positions[:,2], zBinEdges)

        #generate x*y*z dimension empty list of lists so can append values of chosen property to it
        binnedValues = [[[[] for _ in range(numZ)] for _ in range(numY)] for _ in range(numX)]
       
        #fill this array with the common id values from the x,y,z binned data for each x,y,z domain grid bin
        for x, y, z, sProp in zip(xBinIndices, yBinIndices, zBinIndices, selectedProperty):
            #add value to array
            #need to -1 as bin indices start from 1.
            binnedValues[x-1][y-1][z-1].append(sProp.tolist())
        
        if average:
            #generate x*y*z dimension empty list of lists so can append values of chosen property to it
            averageValues = [[[[] for _ in range(numZ)] for _ in range(numY)] for _ in range(numX)]
            for x in range(numX):
                for y in range(numY):
                    for z in range(numZ):
                        #average all values in array and replace with these values
                        binVal = binnedValues[x][y][z]
                        if binVal == []:
                            pass
                        else:
                            averageValues[x][y][z] = numpy.mean(binVal, axis=0).tolist()
            
            return numpy.asarray(averageValues), xBinCoords, yBinCoords, zBinCoords

        #return as a numpy array for easier slicing of data
        return numpy.asarray(binnedValues), xBinCoords, yBinCoords, zBinCoords

    def getBinCoords(self, axisBinEdges):
        """Returns numpy.ndarray of 1D coordinates for the center of a given list of bin edges."""
        binCoords = []
        axisBinEdges = axisBinEdges.tolist()
        #go through all elements of axisbinedges apart from the last one, 
        #and calculate the average value of adjacent pairs to get the center point between.
        for i in range(len(axisBinEdges)-1):
            value = numpy.mean([axisBinEdges[i], axisBinEdges[i+1]])
            binCoords.append(value)
        return numpy.asarray(binCoords)


    '''
    __________________________________
    Get Geometry Triangle Instance from reference triangle ID
    __________________
    '''
    def getGeometryTriangle(self, id):
        """Returns Particle object used to group and access data for a specific particle.
        
        Arguments:
        ----------
        id -- geometry triangle's reference ID number
        """
        gType = self.getGeometryType(id)
        return GeometryTriangle(self.__fname, self.__fileVersion, self.__timestep, gType, self.__creatorData, id)


    #get geometry number from inputted triangle id to allow easier way to 
    def getGeometryType(self, id):
        """Returns integer h5 geometry number for a given geometry triangle id.
        
        Keyword Arguments:
        ------------------
        id -- triangle ID number from a geometry that is to be identified
        """
        #TODO
        geomType = -1 #will only still be -1 if particle id doesn't exist
        for gType in self.__geometryType:
            idSet = (gType.getTriangleIdsSet())
            if id in idSet:
                geomType = gType.getType()
                break
        return geomType
        #TODO end
    
    '''
    __________________________________
    Get Timestep File Version Information
    __________________________________

    '''
    def getFileVersion(self):
        """Returns file version for current timestep."""
        return self.__fileVersion
    
    '''
    __________________________________
    Utilities to get Timestep Metadata
    __________________________________
    
    '''

    def __getTimestep(self):
        """Returns accurate value for timestep from metadata in the hdf5 file."""
        f = h5py.File(self.__fname,'r')
        result = f['TimestepData/' + self.__timestep].attrs['time']
        f.close()
        return result