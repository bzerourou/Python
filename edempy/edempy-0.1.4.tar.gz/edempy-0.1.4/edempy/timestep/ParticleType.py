'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py

import math
from .BinClass import BinClass
from .CustomProperties import CustomProperties

class ParticleType(BinClass):
    """ParticleType class used to access data for a type of particle from current timestep.

    Attributes:
    -----------
    numParticles -- number of particles of current type and timestep
    idToIndex -- dictionary used to get row index for a particle from given id
    indexToId -- dictionary used to get id for a particle from given row number
    options -- list of available property options that can be used to bin data
    """
    #open h5 file and get path to particle as string, count number of types of particle materials
    def __init__(self, fname, creatorData, fileVersion, timestep, particleType, dMin, dMax, id=None):
        super().__init__(self, dMin, dMax) #get access to bin class functions
        self.__fname = fname
        self.__creatorData = creatorData
        self.__fileVersion = fileVersion
        self.__timestep = timestep
        self.__particleType = particleType
        #keep hdf5 path to ParticleTypes group as string
        self.__particlePath = 'TimestepData/' + str(self.__timestep) + '/ParticleTypes/' + str(self.__particleType)

        #save the domain max and min values
        self.__dMin = dMin
        self.__dMax = dMax

        self.__id = id

        ##@var numParticles
        # number of particles of current type and timestep
        self.numParticles = self.getNumParticles()

        ##@var idToIndex
        # dictionary used to get row index for a particle from given id
        self.idToIndex = None #dict(zip(ids, relativeIndex))

        ##@var indexToId
        # dictionary used to get id for a particle from given row number
        self.indexToId = None #dict(zip(relativeIndex, ids))

        ##@var options
        # list of available property options that can be used to bin data
        self.options = ['ids', 'position', 'velocity', 'angular velocity', 'creation time',
        'scale', 'external force torque', 'force torque', 'orientation', 'spheres',
        'us_force torque']

        if self.__creatorData._CreatorData__demfileVersion >= 2621972: # from this version onwards we have custom property meta data stored in the dem file
            self.customProperties = {}
            self.numCustomProperties = self.__creatorData.numParticleCustomProperties

            for i, name, h5name in zip(range(self.numCustomProperties), self.__creatorData.particleCustomPropertyNames, self.__creatorData.h5ParticleCustomPropertyNames):
                customProp = CustomProperties(self.__fname, self.__fileVersion, i, self.__particlePath)
                
                self.customProperties[i] = customProp
                self.customProperties[name] = customProp
                self.customProperties[h5name] = customProp
        else:
            #instantiate a CustomProperty object for each custom property present for particle type
            try:
                temp = h5py.File(self.__fname, 'r')
                self.numCustomProperties = len(list(temp[self.__particlePath + '/CustomProperties/'].keys()))
                temp.close()
            except KeyError:
                self.numCustomProperties = 0

            # create array of custom properties, accessed by index number not necessarily the same as hdf5 number TODO make these numbers match
            self.customProperties = []
            for i in range(self.numCustomProperties):
                self.customProperties.append(CustomProperties(self.__fname, self.__fileVersion, i, self.__particlePath))

    # Method used to print particle type and id as string
    def __str__(self):
        """Return String representation of current particle or particles."""
        return "Particle Type: " + str(self.__particleType) + ", ID: " + str(self.__id)

    #extract particle type from current particle (should be unnecessary)

    def getType(self):
        """Return integer value for particle type as seen in h5 file."""
        return int(self.__particleType)

    '''
    ____________________

    GET GENERIC PROPERTY
    ____________________

    '''
    #function used to clean up code, and make it easier to read.
    #default argument is used to return an array of correct shape for associated property if
    #it is not found
    #Therefore if 3d array was asked for (e.g. 3d velocity. 3d position, etc...),
    #function will still return correct shape of array.
    #defaults to 1d array if argument is not given
    def getProperty(self, option, id=None, default = [numpy.nan]):
        """Returns (multi-dimensional) numpy.ndarray of chosen particle type data.

        Arguments:
        ----------
        option -- string - name of property
        -> 'ids', 'position', 'velocity', 'angular velocity', 'creation time',
        'scale', 'external force torque', 'force torque', 'orientation', 'spheres',
        'us_force torque'

        id -- id number of particle used to get data for a single specific particle
        default -- default data to be returned if no data are found in h5 file
        """
        with h5py.File(self.__fname, 'r') as f:
            if self.numParticles == 0:
                raise KeyError #return numpy.asarray(default)
            elif id == None:
                result = numpy.asarray(f[self.__particlePath + '/' + option])
                return result
            else:
                #setup mapping between index and id for particles
                self.setupIdsDict()
                #get corresponding index for id, default to None if non-existant
                index = self.idToIndex.get(id, None)
                if index != None:
                    result = numpy.asarray(f[self.__particlePath+'/' + option][index])
                    return result
                else:
                    raise KeyError #return numpy.asarray(default)

        return numpy.asarray(default)

    def getAttribute(self, option):
        """Returns value for chosen particle attribute

        Keyword Arguments:
        ----------
        path -- path in h5 file to particle data
        option -- string - name of attribute
        -> 'name', 'material name', 'raw volume', 'raw mass', 'raw inertia', 
        """
        result = None

        try:
            with h5py.File(self.__fname, 'r') as f:
                result = f[self.__particlePath].attrs[option]

        except KeyError as e:
            print("Unable to get " + option + " from data, there are " + str(self.numParticles) + " particles of type " + self.__particleType + " in current timestep \n->" + str(e))
        return result

    '''
    IDS
    ___
    '''

    def setupIdsDict(self):
        """Set up mapping of particle index values to ids in order to access particle date by id."""

        #check there are particles present then pair all ids for current type and timestep with index number if not already set up
        if (self.numParticles > 0 and (self.idToIndex == None) and (self.indexToId == None)):
            #get list of ids
            ids = self.getIds()
            #get positional index for each
            relativeIndex = []
            for i in range(len(ids)):
                relativeIndex.append(i)

            ##@var idToIndex
            # dictionary used to get row index for a particle from given id
            self.idToIndex = dict(zip(ids, relativeIndex))

            ##@var indexToId
            # dictionary used to get id for a particle from given row number
            self.indexToId = dict(zip(relativeIndex, ids))


    def emptyIdsDict(self):
        """Clear dictionaries mapping particle index values to ids in order to free up memory."""
        #remove elements and set values back to None
        self.idToIndex.clear()
        self.idToIndex = None

        self.indexToId.clear()
        self.indexToId = None



    def getIds(self):
        """Returns numpy.ndarray of ids for particle type in current timestep."""
        return self.getProperty('ids')


    def getIdsSet(self):
        """Returns set of ids for particle type in current timestep."""
        return set(self.getProperty('ids'))

    def getNumParticles(self):
        """Returns int value of number of particles of this type in current timestep."""
        try:
            f = h5py.File(self.__fname, 'r')
            result = int(f[self.__particlePath].attrs['size'])
            f.close()
            return result
        except:
            result = int(0)
        return result

    '''
    POSITION
    ____________
    '''

    def getPositions(self, id = None):
        """Returns numpy.ndarray of 3D positions for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('position', id, [numpy.nan,numpy.nan,numpy.nan])


    def getXPositions(self, id = None):
        """Returns numpy.ndarray of x positions for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getPositions(id)[:,0]
        else:
            return self.getPositions(id)[0]


    def getYPositions(self, id = None):
        """Returns numpy.ndarray of y positions for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0:
            return self.getPositions(id)[:,1]  # need to check number of particles aswell so we use the correct number of indices here
        else:
            return self.getPositions(id)[1]


    def getZPositions(self, id = None):
        """Returns numpy.ndarray of z positions for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getPositions(id)[:,2]
        else:
            return self.getPositions(id)[2]

    '''
    VELOCITY
    ____________
    '''

    def getVelocities(self, id = None):
        """Returns numpy.ndarray of 3D velocities for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('velocity',  id, [numpy.nan,numpy.nan,numpy.nan])


    def getXVelocities(self, id = None):
        """Returns numpy.ndarray of x component of velocity for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getVelocities(id)[:,0]
        else:
            return self.getVelocities(id)[0]


    def getYVelocities(self, id = None):
        """Returns numpy.ndarray of y component of velocity for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getVelocities(id)[:,1]
        else:
            return self.getVelocities(id)[1]


    def getZVelocities(self, id = None):
        """Returns numpy.ndarray of z component of velocity for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getVelocities(id)[:,2]
        else:
            return self.getVelocities(id)[2]

    '''
    ANGULAR VELOCITY
    ________________
    '''

    def getAngularVelocities(self, id = None):
        """Returns numpy.ndarray of 3D angular velocities for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('angular velocity',  id, [numpy.nan,numpy.nan,numpy.nan])


    def getXAngularVelocities(self, id = None):
        """Returns numpy.ndarray of x component of angular velocity for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getAngularVelocities(id)[:,0]
        else:
            return self.getAngularVelocities(id)[0]


    def getYAngularVelocities(self, id = None):
        """Returns numpy.ndarray of y component of angular velocity for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getAngularVelocities(id)[:,1]
        else:
            return self.getAngularVelocities(id)[1]


    def getZAngularVelocities(self, id = None):
        """Returns numpy.ndarray of z component of angular velocity for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getAngularVelocities(id)[:,2]
        else:
            return self.getAngularVelocities(id)[2]

    '''
    CREATION TIME
    _____________
    '''

    def getCreationTimes(self, id = None):
        """Returns numpy.ndarray of creation times for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('creation time', id)

    '''
    SCALE
    _____
    '''

    def getScales(self, id = None):
        """Returns numpy.ndarray of scales factors for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('scale', id)

    '''
    EXTERNAL FORCE TORQUE
    _____________________
    '''

    def __getExternalForceTorque(self, id = None):
        """Returns 7 column numpy.ndarray of external force (x,y,z), external torque (x,y,z) and magnitude of external compressive force for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('external force torque', id, [ numpy.nan, numpy.nan,
                                                            numpy.nan, numpy.nan,
                                                            numpy.nan, numpy.nan, numpy.nan ])


    def getExternalForce(self, id = None):
        """Returns 3D numpy.ndarray of external force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getExternalForceTorque(id)[:,:3]
        else:
            return self.__getExternalForceTorque(id)[:3]


    def getXExternalForce(self, id = None):
        """Returns numpy.ndarray of x component of external force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getExternalForce(id)[:,0]
        else:
            return self.getExternalForce(id)[0]




    def getYExternalForce(self, id = None):
        """Returns numpy.ndarray of y component of external force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getExternalForce(id)[:,1]
        else:
            return self.getExternalForce(id)[2]



    def getZExternalForce(self, id = None):
        """Returns numpy.ndarray of z component of external force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getExternalForce(id)[:,2]
        else:
            return self.getExternalForce(id)[2]



    def getExternalTorque(self, id = None):
        """Returns 3D numpy.ndarray of external torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getExternalForceTorque(id)[:,3:6]
        else:
            self.setupIdsDict()
            return self.__getExternalForceTorque(id)[3:6]


    def getXExternalTorque(self, id = None):
        """Returns numpy.ndarray of x component of external torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getExternalTorque(id)[:,0]
        else:
            return self.getExternalTorque(id)[0]



    def getYExternalTorque(self, id = None):
        """Returns numpy.ndarray of y component of external torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getExternalTorque(id)[:,1]
        else:
            return self.getExternalTorque(id)[1]


    def getZExternalTorque(self, id = None):
        """Returns numpy.ndarray of z component of external torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getExternalTorque(id)[:,2]
        else:
            return self.getExternalTorque(id)[2]



    def getExternalMagnitudeOfCompressibility(self, id = None):
        """Returns numpy.ndarray of external magnitude of compressibility on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getExternalForceTorque(id)[:,6]
        else:
            return self.__getExternalForceTorque(id)[6]

    '''
    FORCE TORQUE
    _____________________
    '''

    def __getForceTorque(self, id = None):
        """Returns 7 column numpy.ndarray of force (x,y,z), torque (x,y,z) and magnitude of compressive force for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('force torque', id, [ numpy.nan, numpy.nan,
                                                  numpy.nan, numpy.nan,
                                                  numpy.nan, numpy.nan, numpy.nan ])


    def getForce(self, id = None):
        """Returns 3D numpy.ndarray of force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getForceTorque(id)[:,:3]
        else:
            self.setupIdsDict()
            return self.__getForceTorque(id)[:3]


    def getXForce(self, id = None):
        """Returns numpy.ndarray of x component of force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getForce(id)[:,0]
        else:
            return self.getForce(id)[0]



    def getYForce(self, id = None):
        """Returns numpy.ndarray of y component of force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getForce(id)[:,1]
        else:
            return self.getForce(id)[1]



    def getZForce(self, id = None):
        """Returns numpy.ndarray of z component of force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getForce(id)[:,2]
        else:
            return self.getForce(id)[2]



    def getTorque(self, id = None):
        """Returns 3D numpy.ndarray of torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getForceTorque(id)[:,3:6]
        else:
            self.setupIdsDict()
            return self.__getForceTorque(id)[3:6]


    def getXTorque(self, id = None):
        """Returns numpy.ndarray of x component of torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getTorque(id)[:,0]
        else:
            return self.getTorque(id)[0]


    def getYTorque(self, id = None):
        """Returns numpy.ndarray of y component of torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getTorque(id)[:,1]
        else:
            return self.getTorque(id)[1]


    def getZTorque(self, id = None):
        """Returns numpy.ndarray of z component of torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.getTorque(id)[:,2]
        else:
            return self.getTorque(id)[2]


    def getMagnitudeOfCompressibility(self, id = None):
        """Returns numpy.ndarray of magnitude of compressibility on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getForceTorque(id)[:,6]
        else:
            self.setupIdsDict()
            return self.__getForceTorque(id)[6]

    '''
    ORIENTATION
    ___________
    '''

    def getOrientation(self, id = None):
        """Returns 4 column numpy.ndarray of w,x,y,z components of quarternion for each particle of given particle type in the current timestep."""
        if id == None:
            id = self.__id
        return self.getProperty('orientation', id, [ numpy.nan, numpy.nan, numpy.nan, numpy.nan ])

    '''
    SPHERES
    _______
    '''

    def getSpheres(self):
        """Returns 4 column numpy.ndarray of name, contactRadius, physicalRadius, (x,y,z) position for each sphere contained in chosen particle type."""
        return self.getProperty('spheres', None, [ numpy.nan, numpy.nan, numpy.nan, numpy.nan ])
    

    def getNumberOfSpheres(self):
        """Returns 4 column numpy.ndarray of name, contactRadius, physicalRadius, (x,y,z) position for each sphere contained in chosen particle type."""
        return len(self.getSpheres())


    def getSphereName(self):
        """Returns numpy.ndarray of sphere names for each sphere contained in chosen particle type."""
        result = []
        temp = self.getSpheres()
        for val in temp:
            result.append(val[0].decode("utf-8"))
        return numpy.asarray(result)


    def __scaleRawValues(self, rawValues, scales, id):
        result = []
        # if no id is given then loop through every scale value in scales
        if id == None and self.__id == None:
            for scale in scales:
                # if there is more than one sphere loop through values for each
                if rawValues.size > 1:
                    temp = []
                    for rawValue in rawValues:
                        temp.append(rawValue * scale)
                    result.append(temp)
                else:
                    # only one sphere present in current particle type, therefore just scale values
                    #temp = (rawValues * scale)
                    result.append(rawValues * scale)
                
        else:
            # an id was specified therefore loop through values for each sphere of chosen particle if there are more than 1 present
            # scales is a single value as id has been used
            if rawValues.size > 1:
                #temp = []
                for rawValue in rawValues:
                    result.append(rawValue * scales)
            else:
                # chosen particle only has 1 sphere therefore return this value scaled
                result.append(rawValues * scales)
        return numpy.asarray(result)  
        


    def getRawSphereContactRadius(self):
        """Returns numpy.ndarray of sphere raw contact radii for each sphere contained in chosen particle type."""
        result = []
        temp = self.getSpheres()
        for val in temp:
            result.append(val[1])
        return numpy.asarray(result)


    def getSphereContactRadius(self, id=None):
        """Returns numpy.ndarray of sphere contact radii for each sphere contained in chosen particle type."""
        rawValues = self.getRawSphereContactRadius()
        scales = self.getScales(id)
        return self.__scaleRawValues(rawValues, scales, id)


    def getRawSpherePhysicalRadius(self):
        """Returns numpy.ndarray of sphere raw physical radii for each sphere contained in chosen particle type."""
        result = []
        temp = self.getSpheres()
        for val in temp:
            result.append(val[2])
        return numpy.asarray(result)


    def getSpherePhysicalRadius(self, id=None):
        """Returns numpy.ndarray of sphere physical radii for each sphere contained in chosen particle type."""
        rawValues = self.getRawSpherePhysicalRadius()
        scales = self.getScales(id)
        return self.__scaleRawValues(rawValues, scales, id)


    def getRawSpherePositions(self):
        """Returns numpy.ndarray of sphere positions with respect to particle center for each sphere contained in chosen particle type."""
        result = []
        temp = self.getSpheres()

        '''
        # check there is raw sphere position data
        count = 0
        for val in temp:
            if not numpy.isnan(val): 
                break
            count+=1
            if(count == len(temp)):
                return [numpy.nan, numpy.nan, numpy.nan]
        '''

        for val in temp:
            result.append(val[3])
        return numpy.asarray(result)


    def getSpherePositions(self, id = None):
        #TODO may break if only one sphere present, or one particle present
        
        # get raw particle sphere positions (raw values used for all particles)
        rawValues = self.getRawSpherePositions()

        '''
        # check there is raw sphere position data
        count = 0
        for val in temp:
            if not numpy.isnan(val): 
                break
            count+=1
            if(count == len(temp)):
                return [numpy.nan, numpy.nan, numpy.nan]
        '''

        #get T,R,S to apply transformation to particles (Translate, Rotate, Scale)
        scales = self.getScales(id)                     # S
        rotationMatrices = self.getRotationMatrices(id) # R
        particlePositions = self.getPositions()         # T

        result = []

        for scale, rotate, translate in zip(scales, rotationMatrices, particlePositions):
            for sphere in rawValues:
                rotatedScaledSphere = numpy.matmul(rotate,(scale * sphere)) # apply scale, then rotate

                # now translate sphere positions
                currentSphere = []
                currentSphere.append(rotatedScaledSphere[0] + translate[0]) #x val
                currentSphere.append(rotatedScaledSphere[1] + translate[1]) #y val
                currentSphere.append(rotatedScaledSphere[2] + translate[2]) #z val
                result.append(currentSphere)            

        return numpy.asarray(result)


    def getSphereXPositions(self, id = None):
        """Returns numpy.ndarray of sphere x positions with respect to particle center for each sphere contained in chosen particle type."""
        return self.getSpherePositions(id)[:,0]


    def getSphereYPositions(self, id = None):
        """Returns numpy.ndarray of sphere y positions with respect to particle center for each sphere contained in chosen particle type."""
        return self.getSpherePositions(id)[:,1]


    def getSphereZPositions(self, id = None):
        """Returns numpy.ndarray of sphere z positions with respect to particle center for each sphere contained in chosen particle type."""
        return self.getSpherePositions(id)[:,2]


    def getRawSphereXPositions(self):
        """Returns numpy.ndarray of sphere x positions with respect to particle center for each sphere contained in chosen particle type."""
        return self.getRawSpherePositions()[:,0]


    def getRawSphereYPositions(self):
        """Returns numpy.ndarray of sphere y positions with respect to particle center for each sphere contained in chosen particle type."""
        return self.getRawSpherePositions()[:,1]


    def getRawSphereZPositions(self):
        """Returns numpy.ndarray of sphere z positions with respect to particle center for each sphere contained in chosen particle type."""
        return self.getRawSpherePositions()[:,2]

    '''
    US_FORCE TORQUE
    _______________
    '''

    def __getUSForceTorque(self, id = None):
        """Returns 7 column numpy.ndarray of US-force (x,y,z), US-torque (x,y,z) and magnitude of US-compressive force for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        return self.getProperty('us_force torque', id, [ numpy.nan, numpy.nan,
                                                     numpy.nan, numpy.nan,
                                                     numpy.nan, numpy.nan, numpy.nan ])


    def getUSForce(self, id = None):
        """Returns 3D numpy.ndarray of US force on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getUSForceTorque(id)[:,:3]
        else:
            self.setupIdsDict()
            return self.__getUSForceTorque(id)[:3]


    def getXUSForce(self, id = None):
        """Returns numpy.ndarray of x component of US force on each particle."""
        if id != None:
            self.setupIdsDict()
        return self.getUSForce(id)[:,0]


    def getYUSForce(self, id = None):
        """Returns numpy.ndarray of y component of US force on each particle."""
        if id != None:
            self.setupIdsDict()
        return self.getUSForce(id)[:,1]


    def getZUSForce(self, id = None):
        """Returns numpy.ndarray of z component of US force on each particle."""
        if id != None:
            self.setupIdsDict()
        return self.getUSForce(id)[:,2]



    def getUSTorque(self, id = None):
        """Returns 3D numpy.ndarray of US torque on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getUSForceTorque(id)[:,3:6]
        else:
            self.setupIdsDict()
            return self.__getUSForceTorque(id)[3:6]


    def getXUSTorque(self, id = None):
        """Returns numpy.ndarray of x component of US torque on each particle."""
        if id != None:
            self.setupIdsDict()
        return self.getUSTorque(id)[:,0]


    def getYUSTorque(self, id = None):
        """Returns numpy.ndarray of y component of US torque on each particle."""
        if id != None:
            self.setupIdsDict()
        return self.getUSTorque(id)[:,1]


    def getZUSTorque(self, id = None):
        """Returns numpy.ndarray of z component of US torque on each particle."""
        if id != None:
            self.setupIdsDict()
        return self.getUSTorque(id)[:,2]



    def getUSMagnitudeOfCompressibility(self, id = None):
        """Returns numpy.ndarray of US magnitude of compressibility on each particle."""
        if id == None:
            id = self.__id
        if id == None and self.numParticles > 0: # need to check number of particles aswell so we use the correct number of indices here
            return self.__getUSForceTorque(id)[:,6]
        else:
            self.setupIdsDict()
            return self.__getUSForceTorque(id)[6]

    '''
    __________________________________
    Utilities to get Particle Metadata
    __________________________________

    '''
    def getName(self):
        """Returns name of particle type as set in EDEM."""
        result = self.getAttribute('name')
        if result is not None:
            return result.decode("utf-8")
        return result

    def getMaterial(self):
        """Returns name of particle material as set in EDEM."""
        result = self.getAttribute('material name')  
        if result is not None:
            return result.decode("utf-8")
        return result
               
    def getRawInertia(self):
        """Returns value of raw inertia of particle type as calculated in EDEM."""
        return self.getAttribute('raw inertia')

    def getRawMass(self):
        """Returns value of raw mass of particle type as calculated in EDEM."""
        return self.getAttribute('raw mass')

    def getRawVolume(self):
        """Returns value of raw volume of particle type as calculated in EDEM."""
        return self.getAttribute('raw volume')


    def getMass(self, id = None):
        """Returns scaled values of mass for each particle in particle type."""
        scales = self.getScales(id)
        rawMass = self.getRawMass()
        result = (scales**3) * rawMass
        return result


    def getVolume(self, id = None):
        """Returns scaled values of volume for each particle in particle type."""
        scales = self.getScales(id)
        rawVolume = self.getRawVolume()
        result = (scales**3) * rawVolume
        return result


    '''
    ______________________________________
    Calculated Kinetic Energy => E = 1/2 * m * v^2
    ______________________________________

    '''

    def getKineticEnergy(self, id = None):
        """Returns numpy.ndarray of kinetic energy for all particles of current type in the current timestep."""
        if id == None:
            id = self.__id
        else:
            self.setupIdsDict()
        
        velocity = self.getVelocities(id)
        mass = self.getMass(id)

        kinetic_energy = []
        for m, v in zip(mass, velocity):
            kinetic_energy.append(0.5 * m * numpy.dot(v, v))

        return kinetic_energy


    '''
    ______________________________________
    Useful Utilities for drawing particles
    ______________________________________

    '''

    def getSphereRadii(self, id = None):
        """Returns numpy.ndarray of the scaled radius of each of the spheres that make up a particle of current type."""
        #number of spheres in particle
        numSpheres = len(self.getSpheres())

        #get radius of each sphere in particle
        radius = []
        for i in range(numSpheres):
            radius.append(self.getSpheres()[i][2])

        #convert to numpy array for easy multiplication by scale
        radius = numpy.asarray(radius)

        if id == None:
            id = self.__id

        scales = self.getScales(id)

        if id != None:
            result = radius * scales
        else:
            #for each scale found, multiply it with the corresponding radius and add to results list
            result = []
            for scale in scales:
                temp = radius * scale
                result.append(temp)
            result = numpy.asarray(result).flatten()

        return result


    def getRawSphereRadii(self):
        """Returns numpy.ndarray of the raw unscaled radius of each of the spheres that make up a particle of current type."""
        #number of spheres in particle
        numSpheres = len(self.getSpheres())

        #get radius of each sphere in particle
        radius = []
        for i in range(numSpheres):
            radius.append(self.getSpheres()[i][2])
        return radius

    # uses the quaternion orientation values to generate a rotation matrix
    # this can be used to draw particles with correct orientation

    def getRotationMatrices(self, id = None):
        """Returns numpy.ndarray of rotation matrices calculated from the quaternion orientation values for each particle."""
        if id == None:
            id = self.__id
        orientations = self.getOrientation(id)
        rotMatrix = []
        if id == None:
            for orient in orientations:
                rotMatrix.append(self.__quaternionToRotationMatrix(orient[0], orient[1], orient[2], orient[3]))
        else:
            self.setupIdsDict()
            rotMatrix.append(self.__quaternionToRotationMatrix(
                            orientations[0], orientations[1], orientations[2], orientations[3]
                            ))
        return rotMatrix

    #convert a given quarternion into the corresponding rotation matrix
    #equation used can be found in eqs 62->70 of:
    # http://mathworld.wolfram.com/EulerAngles.html

    def __quaternionToRotationMatrix(self,w,x,y,z):
        """Returns rotation matrix calculated from quaternion for a single particle."""
        #although different from the formula in the link above, this (transposed formula) gives same orientation result as edem when the two are compared
        a = []
        a.append(w**2 + x**2 - (y**2) - (z**2))
        a.append(2*(x*y - w*z))
        a.append(2*(x*z + w*y))

        b = []
        b.append(2*(x*y + w*z))
        b.append(w**2 - (x**2) + (y**2) - (z**2))
        b.append(2*(y*z - w*x))

        c = []
        c.append(2*(x*z - w*y))
        c.append(2*(y*z + w*x))
        c.append(w**2 - (x**2) - (y**2) + (z**2))

        rotMatrix = []
        rotMatrix.append(a)
        rotMatrix.append(b)
        rotMatrix.append(c)

        return numpy.asarray(rotMatrix)

