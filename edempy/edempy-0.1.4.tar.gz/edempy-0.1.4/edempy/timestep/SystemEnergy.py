'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy 
import h5py


class SystemEnergy:
    """SystemEnergy class used to access system energy data from current timestep.
    
    Attributes:
    -----------
    options -- list of available property options that can be chosen
    """
    

    def __init__(self, fname, fileVersion, timestep):
        self.__fname= fname
        self.__fileVersion = fileVersion
        self.__timestep = timestep
        #keep hdf5 path to bonds group as string
        self.__energyPath = 'TimestepData/' + self.__timestep + '/SystemEnergy/' 
        self.__tStepEnergyPath = self.__energyPath + '/TimestepEnergy/'
        
        ##@var options
        # list of available property options that can be chosen
        self.options = ['energy', 'kinetic energy', 'potential energy', 'Loss From Capping', 
        'Loss From Contacts', 'created particles', 'destroyed particles', 'external', 
        'kinetic energy', 'potential energy']



    def getAttribute(self, path, option):
        """Returns value of chosen system energy data.

        Keyword Arguments:
        ----------
        path -- path in h5 file to system energy data
        option -- string - name of attribute
        -> 'energy', 'kinetic energy', 'potential energy', 'Loss From Capping', 
        'Loss From Contacts', 'created particles', 'destroyed particles', 'external', 
        'kinetic energy', 'potential energy'
        """
        f = h5py.File(self.__fname, 'r')
        result = f[path].attrs[option]
        f.close()
        return result

    '''
    Get System Energy attribute values
    _______________
    '''
    

    def getSystemEnergy(self):
        """Returns value of system energy at current timestep."""
        return self.getAttribute(self.__energyPath, 'energy')
    

    def getSystemKineticEnergy(self):
        """Returns value of system kinetic energy at current timestep."""
        return self.getAttribute(self.__energyPath, 'kinetic energy')
    

    def getSystemPotentialEnergy(self):
        """Returns value of system potential energy at current timestep."""
        return self.getAttribute(self.__energyPath, 'potential energy')


    '''
    Get Timestep Energy attribute values
    _______________
    '''
    

    def getLossFromCapping(self):
        """Returns value of energy loss due to capping at current timestep."""
        return self.getAttribute(self.__tStepEnergyPath,'Loss From Capping')
    

    def getLossFromContacts(self):
        """Returns value of energy loss due to contacts at current timestep."""
        return self.getAttribute(self.__tStepEnergyPath,'Loss From Contacts')
    

    def getCreatedParticles(self):
        """Returns value of energy of created particles at current timestep."""
        return self.getAttribute(self.__tStepEnergyPath,'created particles')
    

    def getDestroyedParticles(self):
        """Returns value of energy of destroyed particles at current timestep."""
        return self.getAttribute(self.__tStepEnergyPath,'destroyed particles')


    def getTimestepExternalEnergy(self):
        """Returns value of external energy at current timestep."""
        return self.getAttribute(self.__tStepEnergyPath,'external')
    

    def getTimestepKineticEnergy(self):
        """Returns value of kinetic energy at current timestep."""
        return self.getAttribute(self.__tStepEnergyPath,'kinetic energy')
    

    def getTimestepPotentialEnergy(self):
        """Returns value of potential energy at current timestep."""
        return self.getAttribute(self.__tStepEnergyPath,'potential energy')