'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy 
import h5py

from .BinClass import BinClass

class Bond(BinClass):
    """Bond class used to access bond data from current timestep.

    Attributes:
    -----------
    options -- list of available property options that can be used to bin data
    """

    #open h5 file and get path to bonds as string

    def __init__(self, fname, fileVersion, timestep, particleType, dMin, dMax):
        self.__fname = fname
        self.__fileVersion = fileVersion
        self.__timestep = timestep
        self.__bondPath = 'TimestepData/' + self.__timestep + '/Bonds/SurfaceSurface' 
        self.__particleType = particleType
        self.__dMin = dMin
        self.__dMax = dMax

        #keep hdf5 path to Particle group as string
        self.__particlePath = 'TimestepData/' + str(self.__timestep) + '/ParticleTypes/'
        
        ##@var options
        # list of available property options that can be used to bin data
        self.options = ['bonds', 'break time', 'normal force', 'normal torque', 'state', 'tangential force', 'tangential torque']
   
    # JPM 02.04.2019 - Added method to get IDs direct from particle ID list
    def getIds(self):
        """Returns 2D numpy.ndarray of id pairs for particles that are in contact with each other."""
        numParticlesbyType = []
        numSpheres = []

        # Open h5 file
        f = h5py.File(self.__fname, 'r')
        # Read num particles by type
        for key in f[self.__particlePath].keys():
            numParticlesbyType.append(int(f[self.__particlePath][key].attrs["size"]))
            # Get number of constituent spheres per particle type
            numSpheres.append(int(len(self.__particleType[key].getSpheres())))

        # Generate empty lookup table
        pIDs = numpy.full([max(numParticlesbyType), len(numParticlesbyType)], numpy.NaN)

        # Read particle IDs for timestep
        for p in range(len(numParticlesbyType)):
            if numParticlesbyType[p] > 0:
                pIDs[:numParticlesbyType[p],p] = f[self.__particlePath][str(p)]["ids"]

        f.close()

        contacts = self.getBonds()
        particle_spheres = numpy.tile(numSpheres, [contacts.shape[0], 1])

        # take() is quicker than choose()
        numSpheres1 = numpy.take(particle_spheres, contacts[:, 0])
        numSpheres2 = numpy.take(particle_spheres, contacts[:, 2])

        indexNumber1 = (contacts[:, 1] - (contacts[:, 1] % numSpheres1)) / numSpheres1
        indexNumber2 = (contacts[:, 3] - (contacts[:, 3] % numSpheres2)) / numSpheres2
        indexNumber1 = indexNumber1.astype(int)
        indexNumber2 = indexNumber2.astype(int)

        idPairs = [pIDs[indexNumber1, contacts[:, 0]],
                   pIDs[indexNumber2, contacts[:, 2]]]

        return numpy.transpose(numpy.array(idPairs)).astype(int)

    def getProperty(self, option):
        """Returns (multi-dimensional) numpy.ndarray of chosen bond data.

        Arguments:
        ----------
        option -- string - name of property 
        -> 'bonds', 'break time', 'normal force', 'normal torque', 'state', 'tangential force', 'tangential torque'
        """

        f = h5py.File(self.__fname, 'r')
        result = f[self.__bondPath + '/'+ option + '/'][:]
        f.close()
        return result


    def getBonds(self):
        """Returns numpy.ndarray of bond data."""
        return self.getProperty('bonds')


    def getTypeIDs(self):
        """Returns numpy.ndarray of bond types for each particle in the bond."""
        #return first and third column of the bond data as this is the particle type
        return self.getBonds()[:,[0,2]]

    def getNumBonds(self):
        """Returns int value of number of bonds in timestep."""
        try:
            f = h5py.File(self.__fname, 'r')
            result = int(f[self.__bondPath].attrs['size'])
            f.close()
            return result
        except:
            result = int(0)
        return result


    def getBreakTime(self):
        """Return numpy.ndarray of bond break times."""
        return self.getProperty('break time')
       

    def getNormalForce(self):
        """Returns 3D numpy.ndarray of bond normal forces."""
        return self.getProperty('normal force')


    def getXNormalForce(self):
        """Returns numpy.ndarray of x component of bond normal forces."""
        return self.getNormalForce()[:,0]
    

    def getYNormalForce(self):
        """Returns numpy.ndarray of y component of bond normal forces."""
        return self.getNormalForce()[:,1]


    def getZNormalForce(self):
        """Returns numpy.ndarray of z components of bond normal forces."""
        return self.getNormalForce()[:,2]


    def getNormalTorque(self):
        """Returns 3D numpy.ndarray of bond normal torques."""
        return self.getProperty('normal torque')


    def getXNormalTorque(self):
        """Returns numpy.ndarray of x component of bond normal torques."""
        return self.getNormalTorque()[:,0]
        

    def getYNormalTorque(self):
        """Returns numpy.ndarray of y component of bond normal torques."""
        return self.getNormalTorque()[:,1]
    

    def getZNormalTorque(self):
        """Returns numpy.ndarray of z component of bond normal torques."""
        return self.getNormalTorque()[:,2]


    def getState(self):
        """Returns numpy.ndarray of bond states."""
        return self.getProperty('state')


    def getTangentialForce(self):
        """Returns 3D numpy.ndarray of bond tangential forces."""
        return self.getProperty('tangential force')


    def getXTangentialForce(self):
        """Returns numpy.ndarray of x component of bond tangential forces."""
        return self.getTangentialForce()[:,0]
        

    def getYTangentialForce(self):
        """Returns numpy.ndarray of y component of bond tangential forces."""
        return self.getTangentialForce()[:,1]


    def getZTangentialForce(self):
        """Returns numpy.ndarray of z component of bond tangential forces."""
        return self.getTangentialForce()[:,2]


    def getTangentialTorque(self):
        """Returns 3D numpy.ndarray of bond tangential torques."""
        return self.getProperty('tangential torque')


    def getXTangentialTorque(self):
        """Returns numpy.ndarray of x component of bond tangential torques."""
        return self.getTangentialTorque()[:,0]


    def getYTangentialTorque(self):
        """Returns numpy.ndarray of y component of bond tangential torques."""
        return self.getTangentialTorque()[:,1]


    def getZTangentialTorque(self):
        """Returns numpy.ndarray of z component of bond tangential torques."""
        return self.getTangentialTorque()[:,2]

    '''
    Calculated Properties
    _____________________
    '''
   

    def getSphereNumbers(self):
        """Returns 2d numpy.ndarray of particle sphere numbers involved in bond."""
        bonds = self.getBonds()
        spherePairs = []
        for bond in bonds:
            #how to extract particle index (row) number from given bond 
            # data (columns 2 and 4) given data column 2 and 4 represent the: 
            # (particle index number * number of spheres in particle type) + sphere number involved in bond
            #therefore in order to get the particle index number back from this data this method must be followed:
            # (particle index number - (particle index number % number of spheres(the remainder)) ) / number of spheres
            pType1 = self.__particleType[bond[0]]
            pType2 = self.__particleType[bond[2]]
            numSpheres1 = len(pType1.getSpheres())
            numSpheres2 = len(pType2.getSpheres())
            sphereNum1 = (bond[1]%numSpheres1)
            sphereNum2 = (bond[3]%numSpheres2)
            spherePairs.append([sphereNum1,sphereNum2])
        return numpy.asarray(spherePairs)


    def getPositions(self):
        """Returns calculated 3D numpy.ndarray of bond positions - the mid point between two particle centers."""
        #get list of id pairs in order to get the particle positions
        idPairs = self.getIds()

        #get bond data in order to get the positions of each particle from this
        bonds = self.getBonds()
        positions = []
        for pair, bond in zip(idPairs,bonds):
            pos1 = self.__particleType[bond[0]].getPositions(pair[0])
            pos2 = self.__particleType[bond[2]].getPositions(pair[1])
            #calculate the average position of both particles to get the midpoint
            midPoint = numpy.mean([pos1,pos2],axis=0)
            positions.append(midPoint)
        return numpy.asarray(positions) 