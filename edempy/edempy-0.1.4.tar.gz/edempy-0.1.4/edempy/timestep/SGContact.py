'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy 
import h5py

from .SingleContact import SingleContact

class SGContact(SingleContact):
    """Surface - geometry class used to access data for a surface to geometry contact for the current timestep.
    Inherits all functions from the singleContact class.
    """
    def __init__(self, fname, fileVersion, tStep, dataPath, particleType, geometry, creatorData, dMin, dMax):
        super().__init__(fname, fileVersion, tStep, dataPath, particleType, creatorData, dMin, dMax)
        self.__particleType = particleType
        self.__geometry = geometry
        self.__fname = fname  
        self.__fileVersion = fileVersion
        self.__timestep = tStep
        self.__creatorData = creatorData
        #keep hdf5 path to Particle group as string
        self.__particlePath = 'TimestepData/' + str(self.__timestep) + '/ParticleTypes/'
        # Keep hdf5 path to geometry group used on currrent timestep
        self.__geomPath = 'TimestepData/' + str(self.__timestep) + '/GeometryGroups/'


    #returns 1d array of negative normal overlap values

    def getNegativeNormalOverlap(self):
        """Returns numpy.ndarray of negative normal overlap values for a surface-geometry contact pair."""
        #get contact data so that particle types are known
        contacts = self.getContacts()
        normalOverlap = self.getProperty('normal overlap')
        sphereNum = self.getSphereNumber()

        negativeOverlap = []
      
        for contact, sphere, normOverlap in  zip(contacts, sphereNum, normalOverlap):
            #using particleType and sphere number can get the contact radius and physical radius for sphere
            contactRadius = self.__particleType[contact[0]].getSphereContactRadius()
            physicalRadius = self.__particleType[contact[0]].getSpherePhysicalRadius()

            negativeOverlap.append((contactRadius[sphere] - physicalRadius[sphere]) - normOverlap)

        return numpy.asarray(negativeOverlap)


    def getSphereNumber(self):
        """Returns numpy.ndarray of particle sphere numbers involved in a surf-geom contact."""
        contacts = self.getContacts()
        sphereNum = []
        for contact in contacts:
            #how to extract particle index (row) number from given contact 
            # data (columns 2 and 4) given data column 2 and 4 represent the: 
            # (particle index number * number of spheres in particle type) + sphere number involved in contact
            #therefore in order to get the particle index number back from this data this method must be followed:
            # (particle index number - (particle index number % number of spheres(the remainder)) ) / number of spheres
            pType = self.__particleType[contact[0]]
            numSpheres = len(pType.getSpheres())
            sphereNum.append(contact[1]%numSpheres)

        return numpy.asarray(sphereNum)

    # JPM 28.03.2019 - Added method to get IDs direct from particle ID list
    # JPM 16.08.2019 - Updated
    def getIds(self):
        """Returns 2D numpy.ndarray of id pairs for particles that are in contact with each other."""
        numParticlesbyType = []
        numSpheres = []
        geomNames = []

        # Open h5 file for current timestep
        f = h5py.File(self.__fname, 'r')
        # Read num particles by type
        for key in f[self.__particlePath].keys():
            numParticlesbyType.append(int(f[self.__particlePath][key].attrs["size"]))
            # Get number of constituent spheres per particle type
            numSpheres.append(int(len(f[self.__particlePath][key]['spheres'])))

        # Read num geometries by type
        for key in f[self.__geomPath].keys():
            geomNames.append(int(key))
        
        # Generate empty lookup table
        pIDs = numpy.full([max(numParticlesbyType), len(numParticlesbyType)], numpy.NaN)

        # Read particle IDs for timestep
        for p in range(len(numParticlesbyType)):
            if numParticlesbyType[p] > 0:
                pIDs[:numParticlesbyType[p], p] = f[self.__particlePath][str(p)]["ids"]
        
        # Close hdf5 file
        f.close()

        # Get contact data from timestep
        contacts = self.getContacts()

        # Get data of elem IDs for each geoemtry - from creator data. 
        # JPM - Issue if geoemtry not present at simualtion start.
        geomIDs = []
        numGeomElems = []

        for geom in range(len(geomNames)):
            geomIDs.append(self.__creatorData.geometry[geom].getTriangleIds())
            numGeomElems.append(len(geomIDs[geom]))

        # Generate empty lookup table
        gIDs = numpy.full([max(numGeomElems), int(geomNames[-1])+1], numpy.NaN)

        # Fill lookup table with appropriate geometries
        for geom in range(len(geomNames)):
            ind = int(geomNames[geom])
            gIDs[:numGeomElems[geom], ind] = geomIDs[geom]


        particle_spheres = numpy.tile(numSpheres, [contacts.shape[0], 1])

        numSpheres1 = numpy.take(particle_spheres, contacts[:, 0])
        indexNumber1 = (contacts[:, 1] - (contacts[:, 1] % numSpheres1)) / numSpheres1
        indexNumber1 = indexNumber1.astype(int)

        # Third column gives the geometry type
        # Fourth column value from the contacts data group is the row number that corresponds to the triangle id in the triangle ids data (starting from 0)
        idPairs = [pIDs[indexNumber1, contacts[:, 0]],
                   gIDs[contacts[:, 3], contacts[:, 2]]]

        return numpy.transpose(numpy.array(idPairs)).astype(int)