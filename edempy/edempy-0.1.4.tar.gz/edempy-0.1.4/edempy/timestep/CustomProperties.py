'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py


class CustomProperties:
    """Class used to get custom property data for a geometry, particle type, contact."""
    
    def __init__(self, fname, fileVersion, index, propertyPath):
        self.__fname = fname
        self.__fileVersion = fileVersion
        self.__index = index

        #keep hdf5 path to Geometry custom propeties as string
        self.__propertyPath = propertyPath + '/CustomProperties/' +  str(self.__index)

    def getData(self):
        """Returns array (n-D) of custom property data.
        """
        f = h5py.File(self.__fname, 'r')
        result = f[self.__propertyPath + '/data/'][:]
        f.close()

        if len(result.shape) > 1 and result.shape[1] == 1:
            #make sure that data in 1D array is accessible via index in the same was as n-dimensional data
            result = result[:,0]
        
        return result
