'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy 
import h5py

from .SingleContact import SingleContact

class SSContact(SingleContact):
    """Surface - surface class used to access data for a surface to surface contact for the current timestep.
    Inherits all functions from the singleContact class.
    """
    def __init__(self, fname, fileVersion, tStep, dataPath, particleType, creatorData, dMin, dMax):
        super().__init__(fname, fileVersion, tStep, dataPath, particleType, creatorData, dMin, dMax)
        self.__particleType = particleType
        self.__fname = fname  
        self.__fileVersion = fileVersion
        self.__timestep = tStep
        self.__creatorData = creatorData
        #keep hdf5 path to Particle group as string
        self.__particlePath = 'TimestepData/' + str(self.__timestep) + '/ParticleTypes/'

    #returns 1d array of negative normal overlap values

    def getNegativeNormalOverlap(self):
        """Returns 2d numpy.ndarray of negative normal overlap values for each particle contact pair."""
        #get contact data so that particle types are known
        contacts = self.getContacts()
        normalOverlap = self.getProperty('normal overlap')
        sphereNums = self.getSphereNumbers()

        result = []

        for contact, sphere, normOverlap in  zip(contacts, sphereNums, normalOverlap):
            #using particleType and sphere number can get the contact radius and physical radius for sphere
            contactRadius1 = self.__particleType[contact[0]].getSphereContactRadius()
            physicalRadius1 = self.__particleType[contact[0]].getSpherePhysicalRadius()
            negativeOverlap1 = ((contactRadius1[sphere[0]] - physicalRadius1[sphere[0]]) - normOverlap)

            contactRadius2 = self.__particleType[contact[2]].getSphereContactRadius()
            physicalRadius2 = self.__particleType[contact[2]].getSpherePhysicalRadius()
            negativeOverlap2 = ((contactRadius2[sphere[1]] - physicalRadius2[sphere[1]]) - normOverlap)
            result.append([negativeOverlap1, negativeOverlap2])
        return numpy.asarray(result)


    def getSphereNumbers(self):
        """Returns 2d numpy.ndarray of particle sphere numbers involved in surf-surf contact."""
       
        contacts = self.getContacts()
        result = []
        for contact in contacts:
            #how to extract particle index (row) number from given contact 
            # data (columns 2 and 4) given data column 2 and 4 represent the: 
            # (particle index number * number of spheres in particle type) + sphere number involved in contact
            #therefore in order to get the particle index number back from this data this method must be followed:
            # (particle index number - (particle index number % number of spheres(the remainder)) ) / number of spheres
            pType1 = self.__particleType[contact[0]]
            pType2 = self.__particleType[contact[2]]
            numSpheres1 = len(pType1.getSpheres())
            numSpheres2 = len(pType2.getSpheres())
            sphereNum1 = (contact[1]%numSpheres1)
            sphereNum2 = (contact[3]%numSpheres2)
            result.append([sphereNum1, sphereNum2])
        return numpy.asarray(result)
      
    # JPM 16.08.2019 - Added method to get IDs direct from particle ID list
    def getIds(self):
        """Returns 2D numpy.ndarray of id pairs for particles that are in contact with each other."""
        numParticlesbyType = []
        numSpheres = []

        # Open h5 file
        f = h5py.File(self.__fname, 'r')

        # Read num particles by type
        for key in f[self.__particlePath].keys():
            numParticlesbyType.append(int(f[self.__particlePath][key].attrs["size"]))
            # Get number of constituent spheres per particle type
            numSpheres.append(int(len(f[self.__particlePath][key]['spheres'])))

        # Generate empty lookup table
        pIDs = numpy.full(
            [max(numParticlesbyType), len(numParticlesbyType)], numpy.NaN)

        # Read particle IDs for timestep
        for p in range(len(numParticlesbyType)):
            if numParticlesbyType[p] > 0:
                pIDs[:numParticlesbyType[p], p] = f[self.__particlePath][str(p)]["ids"]

        # Close hdf5 file
        f.close()

        contacts = self.getContacts()
    
        particle_spheres = numpy.tile(numSpheres, [contacts.shape[0], 1])

        # take() is quicker than choose()
        numSpheres1 = numpy.take(particle_spheres, contacts[:, 0])
        numSpheres2 = numpy.take(particle_spheres, contacts[:, 2])

        indexNumber1 = (contacts[:, 1] - (contacts[:, 1] % numSpheres1)) / numSpheres1
        indexNumber2 = (contacts[:, 3] - (contacts[:, 3] % numSpheres2)) / numSpheres2
        indexNumber1 = indexNumber1.astype(int)
        indexNumber2 = indexNumber2.astype(int)

        idPairs = [pIDs[indexNumber1, contacts[:, 0]],
                   pIDs[indexNumber2, contacts[:, 2]]]

        return numpy.transpose(numpy.array(idPairs)).astype(int)

