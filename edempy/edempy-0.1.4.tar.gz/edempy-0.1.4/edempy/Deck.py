'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
from .timestep.Timestep import Timestep
from .creatorData.CreatorData import CreatorData
from . import FileUtil
import numpy
import h5py
import glob

class Deck:
    """Deck class used to access data from an EDEM simulation deck.

    Attributes:
    -----------
    creatorData -- access simulation set up data from first timestep (from 0.h5 file)

    domainMax -- 3D position of the maximum x,y,z values of the simulation domain
    domainMin -- 3D position of the minimum x,y,z values of the simulation domain

    numGeoms -- number of geometries present in simulation
    numTypes -- number of types of particle present in the simulation

    particleNames -- list of particle names, as set by user in EDEM
    materialNames -- list of material names, as set by user in EDEM
    interactionPairs -- list of material interaction pairs used in the EDEM simulation
    geometryNames -- list of geometry names, as set by user in EDEM
    h5ParticleTypes -- list of particle type numbers as they appear in h5 file
    h5GeometryTypes -- list of geometry type numbers as they appear in h5 file

    timestep -- dictionary of Timestep objects used to access simulation data for each Timestep
    numTimesteps -- the number of timesteps found in the deck

    h5TimestepKeys -- list of strings of shortened timestep values, used as directory names in h5 file
    timestepKeys -- list of strings of accurate timestep values, the exact output save time from EDEM

    h5TimestepValues -- list of float values of shortened timestep values, used as directory names in h5 file
    timestepValues -- list of float values of accurate timestep values, the exact output save time from EDEM
    """

    #open h5 file and get path to particle as string, count number of types of
    # particle materials

    def __init__(self, deckname):
        """Constructor for Deck class.

        Keyword Arguments:
        ------------------
        deckname -- string, the path to and name of EDEM deck that data is to be read from
        """

        if FileUtil.dataDirectoryExists(deckname) == False:
            print("Could not open deck \"" + deckname + "\"")
            exit(1)
            
        self.__deckname = deckname
        #path to folder containing h5 files
        self.__dataPath = FileUtil.dataDirectory(deckname)
        #list of h5 files with paths (adds /*.h5 to datapath)
        self.__h5files = FileUtil.h5fileList(self.__dataPath)

        ##@var creatorData
        # access simulation set up data from first timestep (from 0.h5 file)
        self.creatorData =  CreatorData(self.__dataPath + '/0.h5', deckname)

        ##@var domainMax
        # 3D position of the maximum x,y,z values of the simulation domain
        self.domainMax = self.creatorData.domain.getMax()

        ##@var domainMin
        # 3D position of the minimum x,y,z values of the simulation domain
        self.domainMin = self.creatorData.domain.getMin()

        ##@var numGeoms
        # number of geometries present in simulation
        self.numGeoms = self.creatorData.numGeoms

        ##@var numTypes
        # number of types of particle present in the simulation
        self.numTypes = self.creatorData.numTypes

        ##@var particleNames
        # list of particle names, as set by user in EDEM
        self.particleNames = self.creatorData.particleNames

        ##@var materialNames
        # list of material names, as set by user in EDEM
        self.materialNames = self.creatorData.materials.getNames()

        ##@var interactionPairs
        # list of material interaction pairs used in the EDEM simulation
        self.interactionPairs = self.creatorData.interactions.getPairs()

       ##@var geometryNames
        # list of geometry names, as set by user in EDEM
        self.geometryNames = self.creatorData.geometryNames

        ##@var h5ParticleTypes
        # list of particle type numbers as they appear in h5 file
        self.h5ParticleTypes = self.creatorData.h5PTypes

        ##@var h5GeometryTypes
        # list of geometry type numbers as they appear in h5 file
        self.h5GeometryTypes = self.creatorData.h5GTypes

        #can change this value to read in every nth file so plots can
        # be made quickly with very large datasets (in less definition)
        skipFactor = 1
        #slice data by going up in steps of skipFactor through the indices
        h5fileList = self.__h5files[::skipFactor]

        lengthPath = len(self.__dataPath) + 1 # add 1 to remove the / from the path

        #sort timesteps into chronological order:
        #sort by number, remove path and .h5 extension from file name,
        #pad with leading zeros (up to 10 digits) so can be sorted numerically
        sortedH5 = sorted(h5fileList, key = lambda x: x[lengthPath:-3].rjust(10, '0'))

        #set up multiple timesteps that can be indexed seperately
        self.__timestep = [ Timestep(h5file, self.numTypes, self.numGeoms, self.domainMin, self.domainMax, self.creatorData) for h5file in (sortedH5) ]

        ##@var timestep
        # dictionary of Timestep objects used to access simulation data for each Timestep
        self.timestep = {} #dictionary access to particleType data


        ##@var numTimesteps
        # the number of timesteps found in the deck
        self.numTimesteps = len(sortedH5)

        ##@var h5TimestepKeys
        # list of strings of shortened timestep values, used as directory names in h5 file
        self.h5TimestepKeys = []

        ##@var timestepKeys
        # list of strings of accurate timestep values, the exact output save time from EDEM
        self.timestepKeys = []

        for fname in sortedH5:
            f = h5py.File(fname, 'r')
            currentTStep = list(f['TimestepData/'].keys())
            self.h5TimestepKeys.append(currentTStep[0])
            self.timestepKeys.append(str((f['TimestepData/' + str(currentTStep[0])].attrs['time'])))
            f.close()

        #create a dictionary to access the particle type data by either using an index number, h5 file number or particle name as set by user.
        # e.g. particle[0], particle['5'], particle['rock particle'] will all return the same thing if particle '5' was named 'rock particle'
        # and was the smallest number value particle in h5 file.
        for index, h5TimestepString, timestepString in zip(range(self.numTimesteps), self.h5TimestepKeys, self.timestepKeys):
            self.timestep[index] = self.__timestep[index]
            self.timestep[str(h5TimestepString)] = self.__timestep[index]
            self.timestep[str(timestepString)] = self.__timestep[index]

        ##@var h5TimestepValues
        # list of float values of shortened timestep values, used as directory names in h5 file
        self.h5TimestepValues = list(map(float, self.h5TimestepKeys))

        ##@var timestepValues
        # list of float values of accurate timestep values, the exact output save time from EDEM
        self.timestepValues = list(map(float, self.timestepKeys))
