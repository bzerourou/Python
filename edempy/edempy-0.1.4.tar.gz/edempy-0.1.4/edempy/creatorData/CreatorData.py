'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py

from .CustomPropertyMetaData import CustomPropertyMetaData
from .Domain import Domain
from .Geometry import Geometry
from .Interactions import Interactions
from .Materials import Materials
from .ParticleType import ParticleType
from .Physics import Physics

class CreatorData:
    """CreatorData class used to access simulation creation data for the 0th timestep.

    Public Attributes:
    -----------
    h5PTypes -- list of particle type numbers as they appear in h5 file
    h5GTypes -- list of geometry type numbers as they appear in h5 file

    numTypes -- number of types of particle present in simulation setup
    numGeoms -- number of geometries present in simulation setup
    
    geometriesWithFactories -- list of geometry numbers (as they appear in h5 files) that contain factories
    geometryNames -- list of geometry names, as set by user in EDEM
    geometry -- dictionary of geometry objects used to get geometry properties from the 0th h5 file

    particleNames -- list of particle names, as set by user in EDEM
    particle -- dictionary of particleType objects used to get particleType properties from 0th h5 file
    
    domain -- domain class object used to extract domain data from 0th h5 file
    interactions -- interactions class object used to get interactions data from the 0th h5 file
    materials -- materials class object used to get materials data from the 0th h5 file
    physics -- physics class object used to get physics model values in the 0th h5 file

    contactPropertyData -- dictionary of CustomPropertyMetaData objects used to access contact custom property meta data
    contactCustomPropertyNames -- list of the names of all the contact custom properties
    numContactCustomProperties -- the number of contact custom properties present in the simulation

    geometryPropertyData -- dictionary of CustomPropertyMetaData objects used to access geometry custom property meta data
    geometryCustomPropertyNames -- list of the names of all the geometry custom properties
    numGeometryCustomProperties -- the number of geometry custom properties present in the simulation
       
    particlePropertyData -- dictionary of CustomPropertyMetaData objects used to access particle custom property meta data
    particleCustomPropertyNames -- list of the names of all the particle custom properties
    numParticleCustomProperties -- the number of particle custom properties present in the simulation
       
    simulationPropertyData -- dictionary of CustomPropertyMetaData objects used to access simulation custom property meta data
    simulationCustomPropertyNames -- list of the names of all the simulation custom properties
    numSimulationCustomProperties -- the number of simulation custom properties present in the simulation
    """

    #open h5 file and get path to particle as string, count number of 
    # types of particle materials

    def __init__(self, fname, deckname):
        self.__fname = fname
        self.__deckname = deckname

        #keep hdf5 path to Geometry Group group as string
        self.__creatorPath = 'CreatorData/0/'

        '''Get specific useful properties from 0.h5 file such as number of geometries, particle types, particle names'''      
        with h5py.File(self.__fname, 'r') as f:
        
            ## @var fileVersion
            # EDEM file version used to write the file
            self.__fileVersion = f[self.__creatorPath].attrs['file version'] 

            ## @var h5PTypes
            # list of particle type numbers as they appear in h5 file
            self.h5PTypes = list(f['CreatorData/0/ParticleTypes/'].keys())

            ## @var h5GTypes
            # list of geometry type numbers as they appear in h5 file
            self.h5GTypes = list(f['CreatorData/0/GeometryGroups/'].keys())
        
            ## @var numTypes
            #  number of types of particle present in the simulation setup
            self.numTypes = len(self.h5PTypes)

            ## @var numGeoms 
            # number of geometries present in the simulation setup
            self.numGeoms = len(self.h5GTypes)


            ##@var geometriesWithFactories
            # list of geometry numbers (as they appear in h5 files) that contain factories
            self.geometriesWithFactories = self.getGeomsWithFactories()

            '''GEOMETRIES'''

            self.__geometryType = [] #list access to geometry type data

            ##@var geometryNames
            # list of geometry names, as set by the user in EDEM
            self.geometryNames = []
            for h5GType in self.h5GTypes:
                self.geometryNames.append(f['CreatorData/0/GeometryGroups/' + str(h5GType)].attrs['name'].decode("utf-8"))
            
            #make list of geometry objects to allow access to the data by indices
            for h5GType, gName in zip(self.h5GTypes, self.geometryNames):
                self.__geometryType.append(Geometry(self.__fname, self.__fileVersion, h5GType, gName))
       
            ##@var geometry
            # dictionary of geometry objects used to get geometry properties from the 0th h5 file
            self.geometry = {} 

            #create a dictionary to access the geometry type data by either using an index number, h5 file number or geometry name as set by user.
            # e.g. geometry[0], geometry['5'], geometry['hopper'] will all return the same thing if geometry '5' was named 'hopper' 
            # and was the first number value geometry in h5 file.
            for index, h5GType, gName in zip(range(self.numGeoms), self.h5GTypes, self.geometryNames):
                self.geometry[index] = self.__geometryType[index]
                self.geometry[str(h5GType)] = self.__geometryType[index]
                self.geometry[str(gName)] = self.__geometryType[index]                                                                 

            '''PARTICLES'''
            ##@var particleNames
            # list of particle names, as set by the user in EDEM
            self.particleNames = []
            self.__particleType = [] #list access to particleType data
            for h5PType in self.h5PTypes:
                self.particleNames.append(f['CreatorData/0/ParticleTypes/' + str(h5PType)].attrs['name'].decode("utf-8"))
           
           
            #make list of particleType objects to allow access to the data by indices
            for h5PType, pName in zip(self.h5PTypes,self.particleNames):
                self.__particleType.append(ParticleType(self.__fname, self.__fileVersion, h5PType, self.geometry, self.geometriesWithFactories, pName))
        
        with h5py.File(self.__deckname, 'r') as f:
            self.__demfileVersion = int(f.attrs['current file version'])
        
        ##@var particle 
        # dictionary of particleType objects used to get particleType properties from 0th h5 file
        self.particle = {} 

        #create a dictionary to access the particle type data by either using an index number, h5 file number or particle name as set by user.
        # e.g. particle[0], particle['5'], particle['rock particle'] will all return the same thing if particle '5' was named 'rock particle' 
        # and was the first number value particle in h5 file.
        for index, h5PType, pName in zip(range(self.numTypes), self.h5PTypes, self.particleNames):
            self.particle[index] = self.__particleType[index]
            self.particle[str(h5PType)] = self.__particleType[index]
            self.particle[str(pName)] = self.__particleType[index]            
       
        '''DOMAIN'''
        ##@var domain 
        # domain class object used to extract domain data from 0th h5 file
        self.domain = Domain(self.__fname, self.__fileVersion)

        '''INTERACTIONS'''
        ##@var interactions 
        # interactions class object used to get interactions data from the 0th h5 file
        self.interactions = Interactions(self.__fname, self.__fileVersion)
        
        '''MATERIALS'''
        ##@var materials 
        # materials class object used to get materials data from the 0th h5 file
        self.materials = Materials(self.__fname, self.__fileVersion, self.particle, self.h5PTypes, self.geometry, self.h5GTypes)

        '''PHYSICS'''
        ##@var physics 
        # physics class object used to get physics model values in the 0th h5 file
        self.physics = Physics(self.__fname, self.__fileVersion)

        '''CUSTOM PROPERTY META DATA'''

        if self.__demfileVersion >= 2621972: # from this version onwards we have custom property meta data stored in the dem file
            #keep hdf5 path to Custom Property Meta Data Group group as string
            self.__customPropMetaDataPath = 'CreatorData/CustomPropertyMetaData/'

            self.__contactPropertyName = 'ContactProperties'
            [
                self.contactPropertyData, 
                self.contactCustomPropertyNames, 
                self.h5ContactCustomPropertyNames, 
                self.numContactCustomProperties
            ] = self.__setupCustomPropertyDataAccess(self.__contactPropertyName)
        
            self.__geometryPropertyName = 'GeometryProperties'
            [
                self.geometryPropertyData, 
                self.geometryCustomPropertyNames, 
                self.h5GeometryCustomPropertyNames, 
                self.numGeometryCustomProperties 
            ] = self.__setupCustomPropertyDataAccess(self.__geometryPropertyName)
        
            self.__particlePropertyName = 'ParticleProperties'
            [
                self.particlePropertyData, 
                self.particleCustomPropertyNames, 
                self.h5ParticleCustomPropertyNames, 
                self.numParticleCustomProperties 
            ] = self.__setupCustomPropertyDataAccess(self.__particlePropertyName)
        
            self.__simulationPropertyName = 'SimulationProperties'
            [
                self.simulationPropertyData, 
                self.simulationCustomPropertyNames, 
                self.h5SimulationCustomPropertyNames, 
                self.numSimulationCustomProperties 
            ] = self.__setupCustomPropertyDataAccess(self.__simulationPropertyName)

    '''
    GET METHODS 
    __________
    '''
        
    def getFileVersion(self):
        """Returns file version for current timestep."""
        return self.__fileVersion

    def getGeomsWithFactories(self):
        """Returns list of numbers representing geometries that contain a particle factory.
        
        Returns:
        --------
        list -- list of strings containing geometry numbers as they appear in h5 file
        """
        
        #open h5 file in read mode, file must exist
        f = h5py.File(self.__fname, 'r')

        geoms = list(f["CreatorData/0/GeometryGroups/"].keys())
        geomsWithFacts = []
        for g in geoms:
            factory = list(f["CreatorData/0/GeometryGroups/"+str(g)+"/Factories/"].keys())
            if factory != []:
                geomsWithFacts.append(g)
        f.close()
        return geomsWithFacts

    def __setupCustomPropertyDataAccess(self, customPropertyType):
        """Returns custom property data, names and number of custom properties present for the input custom property type.
        Arguments:
        ----------
        customPropertyType -- a string representing one of the following 4 types of custom property: ['ContactProperties', 'GeometryProperties', 'ParticleProperties', 'SimulationProperties']
        """
        with h5py.File(self.__deckname, 'r') as f:
        
            customPropertyPath = self.__customPropMetaDataPath + customPropertyType
            customPropertyData = {}
            customPropertyNames = []
            numCustomProperties = f[customPropertyPath].attrs['finalised property index'] + 1

            h5CustomPropNames = list(f[customPropertyPath].keys())

            for i, h5CustomPropName in zip(range(numCustomProperties), h5CustomPropNames):
                customProperty = CustomPropertyMetaData(self.__deckname, customPropertyPath, i)
                customPropertyName = f[customPropertyPath + '/' + str(i)].attrs['name'].decode("utf-8")

                customPropertyData[i] = customProperty
                customPropertyData[customPropertyName] = customProperty
                customPropertyData[h5CustomPropName] = customProperty
                customPropertyNames.append(customPropertyName)
        
            return customPropertyData, customPropertyNames, h5CustomPropNames, numCustomProperties
