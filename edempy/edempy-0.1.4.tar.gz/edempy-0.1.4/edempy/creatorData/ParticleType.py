'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import h5py
import numpy


class ParticleType:
    """ParticleType class used to access simulation particle type data for the 0th timestep simmulation setup."""

    def __init__(self, fname, fileVersion, index, geometryType, gWithFacts, pName):
        self.__fname = fname
        self.__fileversion = fileVersion
        self.__index = index #index number of particle as seen in h5 file
        self.__pName = pName #string name of particle type as seen in particle metadata attribute and set by user in EDEM
        self.__particlePath = "CreatorData/0/ParticleTypes/" + str(self.__index) +"/"
        self.__geometryType = geometryType
        self.__geomWithFacts = gWithFacts
    
    '''
    GET METHODS
    ___________
    '''


    def getSpheres(self):
        """Returns 4 column numpy.ndarray of name, contactRadius, physicalRadius, (x,y,z) position for each sphere contained in chosen particle type."""
        f = h5py.File(self.__fname, 'r')   
        result = numpy.asarray(f[self.__particlePath + "spheres/"])
        f.close()
        return result


    def getName(self):
        """Returns name of particle type as set in EDEM."""
        #is returned as a bytes literal so is prefixed with b' at start and ' at end so 
        # decode it to get actual string
        f = h5py.File(self.__fname, 'r')
        result = f[self.__particlePath].attrs['name'].decode("utf-8") 
        f.close()
        return result


    def getMaterial(self):
        """Returns name of particle material as set in EDEM."""
        #is returned as a bytes literal so is prefixed with b' at start and ' at end so 
        # decode it to get actual string
        f = h5py.File(self.__fname, 'r')
        result = f[self.__particlePath].attrs['material name'].decode("utf-8")
        f.close()
        return result


    def getRawInertia(self):
        """Returns value of raw inertia of particle type as calculated in EDEM."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__particlePath].attrs['raw inertia']
        f.close()
        return result


    def getRawMass(self):
        """Returns value of raw mass of particle type as calculated in EDEM."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__particlePath].attrs['raw mass']
        f.close()
        return result


    def getRawVolume(self):
        """Returns value of raw volume of particle type as calculated in EDEM."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__particlePath].attrs['raw volume']
        f.close()
        return result