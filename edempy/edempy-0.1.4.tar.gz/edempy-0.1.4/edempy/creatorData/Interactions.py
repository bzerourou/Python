'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py


class Interactions:
    """Interactions class used to access simulation particle interaction data from the 0th timestep.

    Attributes:
    -----------
    numInteractions -- number of interaction pairs in simulation
    """

    def __init__(self, fname, fileVersion):
        self.__fname = fname
        self.__fileversion = fileVersion
        #keep hdf5 path to Interactions as string
        self.__interPath = 'CreatorData/0/Interactions/'
        
        temp = h5py.File(self.__fname, 'r')
        ##@var numInteractions 
        # number of interaction pairs in simulation
        self.numInteractions = len(temp[self.__interPath])
        temp.close()
    '''
    GET METHODS
    '''


    def getInteractions(self):
        """Returns 4 column numpy.ndarray of interaction data: material pairs involved in interaction, coefficients of restitution, static friction and rolling friction."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__interPath][:]
        f.close()
        return result


    def getPairs(self):
        """Returns numpy.ndarray of material pairs that have interactions with each other."""
        temp = self.getInteractions()
        result = []
        for i in range(self.numInteractions):
            result.append(temp[i][0].decode("utf-8"))
        return result


    def getRestitution(self):
        """Returns numpy.ndarray of coefficients of restitution from the interactions data set."""
        temp = self.getInteractions()
        result = []
        for i in range(self.numInteractions):
            result.append(temp[i][1])
        return result


    def getStaticFriction(self):
        """Returns numpy.ndarray of coefficients of static friction from the interactions data set."""
        temp = self.getInteractions()
        result = []
        for i in range(self.numInteractions):
            result.append(temp[i][2])
        return result


    def getRollingFriction(self):
        """Returns numpy.ndarray of coefficients of rolling friction from the interactions data set."""
        temp = self.getInteractions()
        result = []
        for i in range(self.numInteractions):
            result.append(temp[i][3])
        return result