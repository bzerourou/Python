'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py


class Geometry:
    """Geometry class used to access simulation geometry data from the 0th timestep.
    
    Attributes:
    -----------
    options -- list of available property options that can be chosen
    """

    def __init__(self, fname, fileVersion, index, gName, id = None):
        self.__fname = fname #h5 file name 
        self.__fileversion = fileVersion
        self.__index = index #index number of geometry as seen in h5 file
        self.__gName = gName #string name of geometry as seen in geometry metadata attribute and set by user in EDEM

        #keep hdf5 path to Geometry Group group as string
        self.__geomPath = 'CreatorData/0/GeometryGroups/' + str(self.__index)
        
        # id for use with individual geometry triangle id numbers
        self.__id = id

        temp = h5py.File(self.__fname, 'r')
        try:
            numGeometryTriangles = int(temp[self.__geomPath  + '/triangle ids'].size)
        except KeyError:
            #no 'ids' directory so there can not be any particles for this type
            numGeometryTriangles = 0
        self.numGeometryTriangles = numGeometryTriangles
        temp.close()

        ##@var options
        # list of available property options that can be chosen
        self.options = ['angvelandposlist', 'bounding box', 'coords', 'force torque', 
        'moment of inertia', 'triangle ids', 'triangle nodes', 'vertex ids']

        ##@var idToIndex 
        # dictionary used to get row index for a geometry triangle from given id
        self.idToIndex = None
            
        ##@var indexToId 
        # dictionary used to get id for a geometry triangle from given row number
        self.indexToId = None 


    def getProperty(self, option, id=None, default = [numpy.nan]):
        """Returns (multi-dimensional) numpy.ndarray of chosen geometry data.

        Keyword Arguments:
        ----------
        option -- string - name of property
        -> 'angvelandposlist', 'bounding box', 'coords', 'force torque', 
        'moment of inertia', 'triangle ids', 'triangle nodes', 'vertex ids'
        id -- triangle id to get property data from
        default -- default return value in case of no data
        """

        with h5py.File(self.__fname, 'r') as f:
            if self.numGeometryTriangles == 0:
                result = numpy.asarray(default)
            elif id == None:
                result = numpy.asarray(f[self.__geomPath + '/' + option])

            else:
                #setup mapping between index and id for geometry triangles
                self.setupIdsDict()
                #get corresponding index for id, default if non-existant
                index = self.idToIndex.get(id,None)
                if index != None:
                    result = numpy.asarray(f[self.__geomPath + '/' + option][index])
                else:
                    result = numpy.asarray(default)

        return result

    '''
    Centre of Mass properties
    '''
    def getCoM(self):
        """Returns the position of the centre of mass of the geometry."""
        with h5py.File(self.__fname, 'r') as f:
            return f[self.__geomPath + '/'].attrs['centre of mass']

    def getOriginalCoM(self):
        """Returns the position of the original centre of mass of the geometry."""
        with h5py.File(self.__fname, 'r') as f:
            return f[self.__geomPath + '/'].attrs['orig centre of mass']


    '''
    Triangle IDs
    ___
    '''
    def setupIdsDict(self):
        """Set up mapping of geometry triangle index values to ids in order to access geometry triangle data by id."""

        #check there are geometry triangles present then pair all ids for current type and timestep with index number if not already set up
        if (self.numGeometryTriangles > 0 and (self.idToIndex == None) and (self.indexToId == None)):
            #get list of ids
            ids = self.getTriangleIds()
            #get positional index for each
            relativeIndex = []
            for i in range(len(ids)):
                relativeIndex.append(i)

            ##@var idToIndex 
            # dictionary used to get row index for a geometry from given id
            self.idToIndex = dict(zip(ids, relativeIndex))
            
            ##@var indexToId 
            # dictionary used to get id for a geometry from given row number
            self.indexToId = dict(zip(relativeIndex, ids))
       

    def emptyIdsDict(self):
        """Clear dictionaries mapping geometry triangle index values to ids in order to free up memory."""
        #remove elements and set values back to None
        self.idToIndex.clear()
        self.idToIndex = None
        
        self.indexToId.clear()
        self.indexToId = None



    def __getAngvelandposlist(self):
        """Non public funciton, returns 2 column numpy.ndarray of 3D angular velocity and 3D position."""
        return self.getProperty('angvelandposlist')


    def getAngularVelocity(self):
        """Returns numpy.ndarray of x,y,z components of angular velocity (from angvelandposlist)."""
        return self.__getAngvelandposlist()[0][0]


    def getXAngularVelocity(self):
        """Returns numpy.ndarray of x component of angular velocity (from angvelandposlist)."""
        return self.getAngularVelocity()[0]
    

    def getYAngularVelocity(self):
        """Returns numpy.ndarray of y component of angular velocity (from angvelandposlist)."""
        return self.getAngularVelocity()[1]
    

    def getZAngularVelocity(self):
        """Returns numpy.ndarray of z component of angular velocity (from angvelandposlist)."""
        return self.getAngularVelocity()[2]



    def getPositionPOA(self):
        """Returns numpy.ndarray of x,y,z components of position of point of action of geometry (from angvelandposlist)."""
        return self.__getAngvelandposlist()[0][1]


    def getXPositionPOA(self):
        """Returns numpy.ndarray of x component of position of point of action of geometry (from angvelandposlist)."""
        return self.getPositionPOA()[0]


    def getYPositionPOA(self):
        """Returns numpy.ndarray of y component of position of point of action of geometry (from angvelandposlist)."""
        return self.getPositionPOA()[1]


    def getZPositionPOA(self):
        """Returns numpy.ndarray of z component of position of point of action of geometry (from angvelandposlist)."""
        return self.getPositionPOA()[2]



    def getBoundingBox(self):
        """Returns numpy.ndarray of minimum and maximum position of bounding box for geometry."""
        return self.getProperty('bounding box')
   

    def getXBoundingBox(self):
        """Returns numpy.ndarray of minimum and maximum x components of position of bounding box for geometry."""
        return self.getBoundingBox()[:,0]


    def getYBoundingBox(self):
        """Returns numpy.ndarray of minimum and maximum y components of position of bounding box for geometry."""
        return self.getBoundingBox()[:,1]


    def getZBoundingBox(self):
        """Returns numpy.ndarray of minimum and maximum z components of position of bounding box for geometry."""
        return self.getBoundingBox()[:,2]


    def getMinBoundingBox(self):
        """Returns numpy.ndarray of minimum position of bounding box for geometry."""
        return self.getBoundingBox()[0,:]
    

    def getXMinBoundingBox(self):
        """Returns numpy.ndarray of minimum x position of bounding box for geometry."""
        return self.getBoundingBox()[0,0]
    

    def getYMinBoundingBox(self):
        """Returns numpy.ndarray of minimum y position of bounding box for geometry."""
        return self.getBoundingBox()[0,1]


    def getZMinBoundingBox(self):
        """Returns numpy.ndarray of minimum z position of bounding box for geometry."""
        return self.getBoundingBox()[0,2]

   

    def getMaxBoundingBox(self):
        """Returns numpy.ndarray of maximum position of bounding box for geometry."""
        return self.getBoundingBox()[1,:]


    def getXMaxBoundingBox(self):
        """Returns numpy.ndarray of maximum x position of bounding box for geometry."""
        return self.getBoundingBox()[1,0]
    

    def getYMaxBoundingBox(self):
        """Returns numpy.ndarray of maximum y position of bounding box for geometry."""
        return self.getBoundingBox()[1,1]


    def getZMaxBoundingBox(self):
        """Returns numpy.ndarray of maximum z position of bounding box for geometry."""
        return self.getBoundingBox()[1,2]



    def getCoords(self, id = None):
        """Returns numpy.ndarray of coordinates of geometry triangle vertices."""
        origCoords = None
        try:
            origCoords = self.getProperty('coords')
        except KeyError:
            pass

        try:
            origCoords = self.getProperty('imported coords')
        except KeyError:
            pass

        if origCoords is None:
            print("No geometry coordinate data found in creatorData for file " + self.__fname)
            return None

        # check if id has been asked for
        if id == None:
            id = self.__id
        if id != None:
            #setup mapping between index and id for geometry triangles
            self.setupIdsDict()
            # get corresponding triangle nodes for given id
            nodes = self.getTriangleNodes(id)
            temp = []
            try:
                temp.append(origCoords[nodes[0]]); temp.append(origCoords[nodes[1]]); temp.append(origCoords[nodes[2]])
                origCoords = temp # update origCoords to only have data for this id
            except IndexError:
                print("triangle id is not valid for this geometry")
                origCoords = [numpy.nan, numpy.nan, numpy.nan]

        return numpy.asarray(origCoords)


    def getXCoords(self):
        """Returns numpy.ndarray of x coordinates of geometry triangle vertices."""
        return self.getCoords()[:,0]


    def getYCoords(self):
        """Returns numpy.ndarray of y coordinates of geometry triangle vertices."""
        return self.getCoords()[:,1]


    def getZCoords(self):
        """Returns numpy.ndarray of z coordinates of geometry triangle vertices."""
        return self.getCoords()[:,2]



    def __getForceTorque(self):
        """Returns 7D numpy.ndarray of 3D force, 3D torque and magnitude of compressibility on each geometry triangle."""
        return self.getProperty('force torque')


    def getForce(self):
        """Returns 3D numpy.ndarray of force on each geometry triangle."""
        return self.__getForceTorque()[:,:3]


    def getXForce(self):
        """Returns numpy.ndarray of x component of force on each geometry triangle."""
        return self.__getForceTorque()[:,0]
    

    def getYForce(self):
        """Returns numpy.ndarray of y component of force on each geometry triangle."""
        return self.__getForceTorque()[:,1]


    def getZForce(self):
        """Returns numpy.ndarray of z component of force on each geometry triangle."""
        return self.__getForceTorque()[:,2]



    def getTorque(self):
        """Returns 3D numpy.ndarray of torque on each geometry triangle."""
        return self.__getForceTorque()[:,3:6]
    

    def getXTorque(self):
        """Returns numpy.ndarray of x component of torque on each geometry triangle."""
        return self.__getForceTorque()[:,3]
    

    def getYTorque(self):
        """Returns numpy.ndarray of y component of torque on each geometry triangle."""
        return self.__getForceTorque()[:,4]
    

    def getZTorque(self):
        """Returns numpy.ndarray of z component of torque on each geometry triangle."""
        return self.__getForceTorque()[:,5]


    def getMagnitudeOfCompressibility(self):
        """Returns numpy.ndarray of magnitude of compressibility on each geometry triangle."""
        return self.__getForceTorque()[:,6]
    


    def getMomentOfInertia(self):
        """Returns numpy.ndarray of moments of inertia of geometry."""
        return self.getProperty('moment of inertia')
 

    def getTriangleIds(self):
        """Returns numpy.ndarray of triangle ids."""
        return self.getProperty('triangle ids')
 
    def getTriangleNodes(self, id = None):
        """Returns numpy.ndarray of triangle nodes that make up geometry (vertex ids used to make geometry triangle)."""
        if id == None:
            id = self.__id
        if id == None and self.numGeometryTriangles > 0:
            result = self.getProperty('triangle nodes')
        else:
            #setup mapping between index and id for geometry triangles
            self.setupIdsDict()
            #get corresponding index for id, return default nan values if non-existant
            index = self.idToIndex.get(id,None)
            if index == None:
                result = [numpy.nan, numpy.nan, numpy.nan]
            else:
                #return triangle nodes for given triangle id
                result = []
                result.append(self.getTriangleNodes()[index])
                # here return 0th element of result to remove unwanted data type info (result is a 2d tuple of values and datatype)
                result = result[0]
        
        return result
  


    def getVertexIds(self):
        """Returns numpy.ndarray of vertex ids that make up geometry."""
        return self.getProperty('vertex ids')



    def getMaterial(self):
        """Returns name of geometry material as set in EDEM."""
        #is returned as a bytes literal so is prefixed with b' at start and ' at end so 
        # decode it to get actual string
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['material name'].decode("utf-8")
        f.close()
        return result


    def getTypeName(self):
        """Returns name of geometry type, one of: cad_geometry, box, polygon, cylinder."""
        #is returned as a bytes literal so is prefixed with b' at start and ' at end so 
        # decode it to get actual string
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['type'].decode("utf-8")
        f.close()
        return result


    ''' 
    -----------------------------------------
    CAD Property Data Extraction 
    -----------------------------------------
    '''

    def getCadTranslationStart(self):
        """Returns CAD Translation start value."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['cad translation axis start']
        f.close()
        return result

    def getCadTranslationEnd(self):
        """Returns CAD Translation end value."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['cad translation axis end']
        f.close()
        return result

    def getCadTranslationDistance(self):
        """Returns CAD Translation distance value."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['cad translation']
        f.close()
        return result

    def getCadRotationStart(self):
        """Returns CAD Rotation start value (start point of rotation axis)."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['cad rotation axis start']
        f.close()
        return result

    def getCadRotationEnd(self):
        """Returns CAD Rotation end value (end point of rotation axis)."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['cad rotation axis end']
        f.close()
        return result
        
    def getCadRotationAngle(self):
        """Returns CAD Rotation angle value (in units set in EDEM - default is radians)."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['cad rotation']
        f.close()
        return result

    ''' 
    -----------------------------------------
    EDEM built in geometry property methods 
    -----------------------------------------
    '''

    '''
    cylinder
    '''
    def getCylinderStart(self):
        """Returns EDEM cylinder start point, i.e. the start point of the cylinder axis used to define the cylinder."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['start point']
        f.close()
        return result

    def getCylinderEnd(self):
        """Returns EDEM cylinder end point, i.e. the end point of the cylinder axis used to define the cylinder."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['end point']
        f.close()
        return result

        '''
        box and polygon
        '''
    def getPolygonCentre(self):
        """Returns centre point of an EDEM polygon or box."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['centre']
        f.close()
        return result

    def getPolygonRotation(self):
        """Returns the angles of rotation for the x, y, z axes for an EDEM polygon or box."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__geomPath].attrs['rotations']
        f.close()
        return result


    '''
    Get geometry numbers that contain factories
    '''

    def getFactoryNames(self):
        """Returns list of factory names for given geometry."""
        #open h5 file in read mode, file must exist
        f = h5py.File(self.__fname, 'r')
        result = list(f[self.__geomPath+"/Factories/"].keys())
        f.close()
        return result


    def getFactoryParticleNames(self, factory):
        """Returns list of particle type names for associated particle factory.
    
        Arguments:
        ----------
        factory -- string - name of factory to get particle names from
        """
        #open h5 file in read mode, file must exist
        f = h5py.File(self.__fname, 'r')
        #get all particle types associated with factory
        result = f[self.__geomPath+"/Factories/"+str(factory)+"/FactType/type names/"][()]
        f.close()
        return result