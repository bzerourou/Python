'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py


class Physics:
    """Physics class used to access simulation physics model data for the 0th timestep simulation setup.

    Attributes:
    -----------
    surfSurf -- singlePhys object used to access surface to surface physics model data
    surfGeom -- singlePhys object used to access surface to geometry physics model data
    """

    def __init__(self, fname, fileVersion):
        self.__fname = fname
        self.__fileversion = fileVersion
        #keep hdf5 path to Interactions as string
        self.__physPath = 'CreatorData/0/PhysicsModels/'

        #get correct paths for surface-surface and surface-geometry contacts
        surfPath = self.__physPath + '/SurfaceSurface'
        geomPath = self.__physPath + '/SurfaceGeometry'

        ##@var surfSurf 
        # singlePhys object used to access surface to surface physics model data
        self.surfSurf = singlePhys(fname, surfPath)
        
        ##@ var surfGeom 
        # singlePhys object used to access surface to geometry physics model data
        self.surfGeom = singlePhys(fname, geomPath)

class singlePhys:
    """singlePhys class used to access properties for surface-surface and surface-geometry physics models."""

    def __init__(self, fname, physPath):
        self.__fname = fname
        self.__physPath = physPath
    

    def getHertzMindlinJKR(self):
        """Returns value for Hertz Mindlin JKR physics model."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__physPath + '/Hertz-Mindlin with JKR/data/'][0]
        f.close()
        return result