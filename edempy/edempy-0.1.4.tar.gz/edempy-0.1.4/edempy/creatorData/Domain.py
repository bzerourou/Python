'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import h5py
import numpy


class Domain:
    """Domain class used to get domain creator data in the 0th h5 file."""

    def __init__(self, fname, fileVersion):
        self.__fname = fname
        self.__fileversion = fileVersion

    '''
    GET METHODS
    _______
    '''


    def getMax(self):
        """Returns numpy.ndarray of 3D position of maximum point of domain."""
        #open h5 file in read-write mode, file must exist
        f = h5py.File(self.__fname, 'r')
        
        #get domain max values
        try:
            result = f["CreatorData/0/Domain/"].attrs['domain max']
        except KeyError:
             #must be older deck version so get domain by doing this:
            result = f['CreatorData/0/domain']
            result = result[()][1][:]
        #close h5 file
        f.close()
        return result


    def getXMax(self):
        """Returns x component of maximum point of domain."""
        return self.getMax()[0]
    

    def getYMax(self):
        """Returns y component of maximum point of domain."""
        return self.getMax()[1]
    

    def getZMax(self):
        """Returns z component of maximum point of domain."""
        return self.getMax()[2]



    def getMin(self):
        """Returns numpy.ndarray of 3D position of minimum point of domain."""
        #open h5 file in read-write mode, file must exist
        f = h5py.File(self.__fname, 'r')
        
        #get domain min values
        try:
            result = f["CreatorData/0/Domain/"].attrs['domain min']
        except KeyError:
            #must be older deck version so get domain by doing this:
            result = f['CreatorData/0/domain']
            result = result[()][0][:]
        #close h5 file
        f.close()
        return result


    def getXMin(self):
        """Returns x component of minimum point of domain."""
        return self.getMin()[0]


    def getYMin(self):
        """Returns y component of minimum point of domain."""
        return self.getMin()[1]


    def getZMin(self):
        """Returns z component of minimum point of domain."""
        return self.getMin()[2]