'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py


class Materials:
    """Materials class used to access simulation particle interaction data from the 0th timestep.

    Attributes:
    -----------
    numMaterials -- number of types of material present in simulation
    """

    def __init__(self, fname, fileVersion, particleType, h5particleIndex, geometryType, h5geometryIndex):
        self.__fname = fname
        self.__fileversion = fileVersion
        #keep hdf5 path to Interactions as string
        self.__materPath = 'CreatorData/0/Materials/'

        temp = h5py.File(self.__fname, 'r')
        ##@var numMaterials 
        # number of types of material present in simulation
        self.numMaterials = len(temp[self.__materPath])
        temp.close()

        #access particle data from particleType class
        self.__particleType = particleType
        self.__h5particleIndex = h5particleIndex
        
        #access geometry data from geometryType class
        self.__geometryType = geometryType
        self.__h5geometryIndex = h5geometryIndex
        
    '''
    GET METHODS
    ''' 
    #get everything contained in materials data set

    def getMaterials(self):
        """Returns 6 column numpy.ndarray of material name, poisson ratio, shear modulus, density, work function, particle type."""
        f = h5py.File(self.__fname, 'r')
        result = f[self.__materPath][:]
        f.close()
        return numpy.asarray(result)


    def getNames(self):
        """Returns numpy.ndarray of material names from the materials data set."""
        temp = self.getMaterials()
        result = []
        for i in range(self.numMaterials):
            result.append(temp[i][0].decode("utf-8"))
        return result

    

    def getPoissonRatio(self):
        """Returns numpy.ndarray of poisson ratio values from the materials data set."""
        temp = self.getMaterials()
        result = []
        for i in range(self.numMaterials):
            result.append(temp[i][1])
        return result
    

    def getShearModulus(self):
        """Returns numpy.ndarray of shear modulus values from the materials data set."""
        temp = self.getMaterials()
        result = []
        for i in range(self.numMaterials):
            result.append(temp[i][2])
        return result
    

    def getDensity(self):
        """Returns numpy.ndarray of density values from the materials data set."""
        temp = self.getMaterials()
        result = []
        for i in range(self.numMaterials):
            result.append(temp[i][3])
        return result
    

    def getWorkFunction(self):
        """Returns numpy.ndarray of work function values from the materials data set."""
        temp = self.getMaterials()
        result = []
        for i in range(self.numMaterials):
            result.append(temp[i][4])
        return result
    

    def getType(self):
        """Return numpy.ndarray of material types from the materials data set."""
        temp = self.getMaterials()
        result = []
        for i in range(self.numMaterials):
            result.append(temp[i][5])
        return result