
'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy
import h5py

class CustomPropertyMetaData:
    """CustomPropertyMetaData class used to access custom property meta data stored in the simulation dem file.
    """

    def __init__(self, fname, customPropertyPath, index):
        self.__fname = fname

        #keep hdf5 path to Custom Property Meta Data Group group as string
        self.__customPropertyPath = customPropertyPath
        self.__index = index

    def getInitialValues(self):
        """Returns numpy.ndarray of custom property initial values."""
        with h5py.File(self.__fname, 'r') as f:
            result = numpy.asarray(f[self.__customPropertyPath + '/' + str(self.__index) + '/initial values'])
            return result

    def getName(self):
        """Returns name of the custom property."""
        with h5py.File(self.__fname, 'r') as f:
            result = f[self.__customPropertyPath + '/' + str(self.__index)].attrs['name'].decode("utf-8")
            return result

    def getNumberOfElements(self):
        """Returns number of data elements in the custom property."""
        with h5py.File(self.__fname, 'r') as f:
            result = f[self.__customPropertyPath + '/' + str(self.__index)].attrs['number of elements']
            return result
