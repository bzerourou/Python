'''
Copyright 2020 DEM Solutions Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''
import numpy

class Bin:
    """
    Constructor for Bin class.
    """
    def translatePointsVectors(self, transform):
        """
        Translate points and vectors for use in searchBin functions.

        Args:
            transform (numpy array): 4x4 transformation matrix.

        Returns:
            points (list): List of translated points defining bin.
            vectors (list): List of rotated vectors defining bin.
        """
        if transform is None:
            points = self.points
            vectors = self.vectors
        else:
            points = []
            for point in self.points:
                points.append(numpy.matmul(transform, numpy.append(point, 1))[:3])
            vectors = []
            R = transform[:3, :3]
            for vector in self.vectors:
                vectors.append(numpy.dot(R, vector))
        return points, vectors

    def returnQueryValue(self, binnedObjects, queryType):
        """
        Return value calculated based on queryType.

        Args:
            binnedObjects (list): List of objects inside Bin.
            queryType (str): String defining query for bin to return. Default
                             returns all objects inside bin. Options = ['max',
                             'min', 'average', 'total'].

        Returns:
            value (list): Value calculated based on queryType.
        """
        # binType = 'max'
        if queryType == 'max':
            if len(binnedObjects[0]) > 1:
                binnedObjectsMag = [numpy.linalg.norm(i) for i in binnedObjects]
                index = numpy.argwhere(numpy.array(binnedObjectsMag) == max(binnedObjectsMag))[0,0]
                value = binnedObjects[index]
            else:
                value = numpy.max(binnedObjects, axis=0)
        # binType = 'min'
        elif queryType == 'min':
            if len(binnedObjects[0]) > 1:
                binnedObjectsMag = [numpy.linalg.norm(i) for i in binnedObjects]
                index = numpy.argwhere(numpy.array(binnedObjectsMag) == min(binnedObjectsMag))[0,0]
                value = binnedObjects[index]
            else:
                value = numpy.max(binnedObjects, axis=0)
        # binType = 'average'
        elif queryType == 'average':
            value = numpy.average(binnedObjects, axis=0)
        # binType = 'total'
        elif queryType == 'total':
            value = numpy.sum(binnedObjects, axis=0)
        return value

    def getBinnedObjects(self, objects, positions, queryType=None, transform=None):
        """
        Get list of objects inside Bin.

        Args:
            objects (list): List of objects to search for inside bin
                            [obj0, obj1, ...].
            positions (list): List of positions of objects to search for inside
                              bin [[x0, y0, z0], [x1, y1, z1], ...].
            queryType (str): String defining type for bin to return. Default
                             returns all objects inside bin. Options = ['max',
                             'min', 'average', 'total'].
            transform (numpy array): 4x4 transformation matrix.

        Returns:
            binnedObjects (list): List of objects inside Bin.

        Notes:
            - Specifying a queryType strictly only works when "objects" is a list
              of ints/floats/doubles or a list of vectors.
        """
        # Step 1: Calculate reference points and vectors.
        points, vectors = self.translatePointsVectors(transform)
        # Step 2: Search for if objects are inside bin.
        binnedObjects = self.searchBin(objects, positions, points, vectors)
        # Step 3: Work out what to return based on queryType
        if queryType != None:
            binnedObjects = self.returnQueryValue(binnedObjects, queryType)
        return binnedObjects

class BoxBin(Bin):
    def __init__(self, origin, xLen, yLen, zLen):
        """
        Constructor for BoxBin class.

        Args:
            origin (list): Position of the origin of the BoxBin [x, y, z].
            xLen (float): x lenght of the BoxBin [m].
            yLen (float): y lenght of the BoxBin [m].
            zLen (float): z lenght of the BoxBin [m].
        """
        self.origin = origin
        self.xLen = xLen
        self.yLen = yLen
        self.zLen = zLen
        # Points
        self.point1 = numpy.array(origin) + numpy.array([0.5 * xLen, 0.5 * yLen, 0.5 * zLen])
        self.point2 = numpy.array(origin) - numpy.array([0.5 * xLen, 0.5 * yLen, 0.5 * zLen])
        self.points = [self.point1, self.point2]
        # Vectors
        self.xvector = (self.point1 - numpy.array([self.xLen, 0.0, 0.0])) - self.point1
        self.yvector = (self.point1 - numpy.array([0.0, self.yLen, 0.0])) - self.point1
        self.zvector = (self.point1 - numpy.array([0.0, 0.0, self.zLen])) - self.point1
        self.vectors = [self.xvector, self.yvector, self.zvector]

    def searchBin(self, objects, positions, points, vectors):
        '''
        BoxBin Search.

        Args:
            objects (list): List of objects to search for inside bin
                            [obj0, obj1, ...].
            positions (list): List of positions of objects to search for inside
                              bin [[x0, y0, z0], [x1, y1, z1], ...].
            points (list): List of points defining bin.
            vectors (list): List of vectors defining bin.

        Returns:
            binnedObjects (list): List of objects inside the bin.
        '''
        point1 = points[0]
        point2 = points[1]
        xvector = vectors[0]
        yvector = vectors[1]
        zvector = vectors[2]
        binnedObjects = []
        for i in range(0, len(objects)):
            if numpy.dot(positions[i] - point1, xvector) >= 0 and numpy.dot(positions[i] - point2, xvector) <= 0: # if inside x bounds
                if numpy.dot(positions[i] - point1, yvector) >= 0 and numpy.dot(positions[i] - point2, yvector) <= 0: # if inside y bounds
                    if numpy.dot(positions[i] - point1, zvector) >= 0 and numpy.dot(positions[i] - point2, zvector) <= 0: # if inside z bounds
                        binnedObjects.append(objects[i])
        return binnedObjects

class CylinderBin(Bin):
    def __init__(self, point1, point2, radius):
        """
        Constructor for CylinderBin class.

        Args:
            point1 (list): First point defining CylinderBin [x, y, z].
            point2 (list): Second point defining CylinderBin [x, y, z].
            radius (float): Radius of CylinderBin [m].
        """
        self.radius = radius
        # Points
        self.point1 = numpy.array(point1)
        self.point2 = numpy.array(point2)
        self.points = [self.point1, self.point2]
        # Vectors
        self.vector = numpy.array(point2) - numpy.array(point1)
        self.vectors = [self.vector]

    def searchBin(self, objects, positions, points, vectors):
        '''
        CylinderBin Search.

        Args:
            objects (list): List of objects to search for inside bin
                            [obj0, obj1, ...].
            positions (list): List of positions of objects to search for inside
                              bin [[x0, y0, z0], [x1, y1, z1], ...].
            points (list): List of points defining bin.
            vectors (list): List of vectors defining bin.

        Returns:
            binnedObjects (list): List of objects inside the bin.
        '''
        point1 = points[0]
        point2 = points[1]
        vector = vectors[0]
        binnedObjects = []
        for i in range(0, len(objects)):
            if numpy.dot(positions[i] - point1, vector) >= 0:
                if numpy.dot(positions[i] - point2, vector) <= 0:
                    if numpy.linalg.norm(numpy.cross(positions[i] - point1, vector)) / numpy.linalg.norm(vector) <= self.radius:
                        binnedObjects.append(objects[i])
        return binnedObjects
