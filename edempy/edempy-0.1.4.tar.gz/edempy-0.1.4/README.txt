# edempy

This is the edempy python scripting library for post-processing and analysis of EDEM simulation decks.
Using this library, it is simple to extract specific data from a simulation deck in an easily customisable and reusable way.

## Getting Started

Firstly make sure your version of python satisfies the prerequisities below, then you can simply copy the edempy source directory to your working directory.

To use edempy in your script you can then import it using
```
import edempy
```
at the top of the script.

To extract data from a simulation deck you can then instantiate a Deck object by using the command
```
deck = edempy.Deck(deckname)
```
to access this feature -> deckname is a string containing the path to and name of an EDEM simulation .dem file.

**Full documentation of edempy can be found in [edempy/docs/html/index.html](./docs/html/index.html)**


### Prerequisites
This library relies on the following python packages:
* [numpy](http://www.numpy.org/)
* [h5py](https://www.h5py.org/)

The easiest way to satisfy the dependencies of edempy is to install the latest version of the [anaconda](https://www.anaconda.com/download/) distribution of python 3 onto your system.
This packaged version of python contains the numpy and h5py packages that are used in this library.

Python 3 was used throughout this library, and therefore it is not backwards compatible with python 2.



### Installing

In order to easily write scripts using edempy, it is recommended that [visual studio code](https://code.visualstudio.com/) is installed on your system. If you install anaconda, this comes as part of the package. This is a light, easily customisable ide that supports python and offers helpful autocomplete suggestions.

Another ide that is recommended for writing python scripts is the [spyder ide](https://www.spyder-ide.org/), which also comes as standard with anaconda.


## Authors

**DEM Solutions Ltd.**


## License

This project is licensed under the Apache License Version 2.0](http://www.apache.org/licenses/LICENSE-2.0)
