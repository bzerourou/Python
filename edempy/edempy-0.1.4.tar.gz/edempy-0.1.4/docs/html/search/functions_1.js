var searchData=
[
  ['datadirectory',['dataDirectory',['../namespaceedempy_1_1_file_util.html#aba2da97924e056e3085a6ac2aecdac86',1,'edempy::FileUtil']]],
  ['datadirectoryexists',['dataDirectoryExists',['../namespaceedempy_1_1_file_util.html#ab51340f4e9e9f9943a5cd2c47c13f277',1,'edempy::FileUtil']]]
];
