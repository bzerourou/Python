var searchData=
[
  ['interactions',['Interactions',['../classedempy_1_1creator_data_1_1_interactions_1_1_interactions.html',1,'edempy::creatorData::Interactions']]]
];
